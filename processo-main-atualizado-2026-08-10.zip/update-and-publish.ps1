{
  "schemaVersion": 14,
  "processNumber": "SEI-030029/004475/2023",
  "officialUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_processo_exibir.php?IC2o8Z7ACQH4LdQ4jJLJzjPBiLtP6l2FsQacllhUf-duzEubalut9yvd8-CzYYNLu7pd-wiM0k633-D6khhQNbktnAd5iwonOrpJKmKvtZqQfhPRIZoJiTRfNxCUWV1x",
  "generatedAt": "2026-07-24T14:17:00.000Z",
  "sourceHash": "44cfbae5451e83ff304729b689d3593566d305f1c18c47dbb3b13b3c9a27e9e5",
  "movements": [
    {
      "dateTime": "24/07/2026 11:17",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "23/07/2026 15:37",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "22/07/2026 17:25",
      "unit": "FAETEC/PRESI",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "18/07/2026 14:48",
      "unit": "FAETEC/SECPRES",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "18/07/2026 14:47",
      "unit": "FAETEC/SECPRES",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/07/2026 14:44",
      "unit": "FAETEC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/07/2026 12:13",
      "unit": "FAETEC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "14/07/2026 12:11",
      "unit": "SEEDUC/GABSEC",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "14/07/2026 11:52",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "13/07/2026 21:31",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/ASSUBEXE"
    },
    {
      "dateTime": "13/07/2026 12:08",
      "unit": "SEEDUC/ASSUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "13/07/2026 12:07",
      "unit": "SEEDUC/ASSUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/ASSUPOF"
    },
    {
      "dateTime": "10/07/2026 14:39",
      "unit": "SEEDUC/ASSUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "10/07/2026 14:14",
      "unit": "SEEDUC/ASSUPOF",
      "description": "Processo remetido pela unidade SEEDUC/SUPOF"
    },
    {
      "dateTime": "09/07/2026 11:56",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "08/07/2026 17:47",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo remetido pela unidade SEEDUC/CHEGAB"
    },
    {
      "dateTime": "08/07/2026 15:25",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "08/07/2026 14:46",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade SEPLAG/CHEGAB"
    },
    {
      "dateTime": "08/07/2026 09:02",
      "unit": "SEPLAG/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "06/07/2026 11:05",
      "unit": "SEPLAG/CHEGAB",
      "description": "Processo remetido pela unidade SEPLAG/SUBORC"
    },
    {
      "dateTime": "06/07/2026 10:58",
      "unit": "FAETEC/SECPRES",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "03/07/2026 19:05",
      "unit": "SEPLAG/SUBORC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "03/07/2026 19:05",
      "unit": "SEPLAG/SUBORC",
      "description": "Processo remetido pela unidade SEPLAG/SUBAORC"
    },
    {
      "dateTime": "03/07/2026 19:05",
      "unit": "SEPLAG/SUBAORC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "03/07/2026 18:58",
      "unit": "SEPLAG/SUBORC",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "03/07/2026 18:57",
      "unit": "SEPLAG/SUBAORC",
      "description": "Processo remetido pela unidade SEPLAG/SUPEFIS"
    },
    {
      "dateTime": "01/07/2026 18:20",
      "unit": "SEPLAG/SUPEFIS",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "01/07/2026 18:19",
      "unit": "SEPLAG/SUPEFIS",
      "description": "Processo remetido pela unidade SEPLAG/SUBAORC"
    },
    {
      "dateTime": "01/07/2026 18:10",
      "unit": "SEPLAG/SUPEFIS",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "01/07/2026 18:08",
      "unit": "SEPLAG/SUBAORC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "01/07/2026 18:01",
      "unit": "SEPLAG/SUPEFIS",
      "description": "Processo remetido pela unidade SEPLAG/SUBORC"
    },
    {
      "dateTime": "01/07/2026 18:01",
      "unit": "SEPLAG/SUBAORC",
      "description": "Processo remetido pela unidade SEPLAG/SUBORC"
    },
    {
      "dateTime": "01/07/2026 17:42",
      "unit": "SEPLAG/SUBORC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "01/07/2026 17:39",
      "unit": "SEPLAG/SUBORC",
      "description": "Processo remetido pela unidade SEPLAG/SUBGEP"
    },
    {
      "dateTime": "30/06/2026 18:31",
      "unit": "SEPLAG/SUBGEP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "30/06/2026 14:43",
      "unit": "SEPLAG/SUBGEP",
      "description": "Processo remetido pela unidade SEPLAG/SUPDP"
    },
    {
      "dateTime": "26/06/2026 10:59",
      "unit": "SEPLAG/SUPDP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/06/2026 10:42",
      "unit": "SEPLAG/SUPDP",
      "description": "Processo remetido pela unidade SEPLAG/SUBGEP"
    },
    {
      "dateTime": "26/06/2026 10:01",
      "unit": "SEPLAG/SUPDP",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "26/06/2026 09:56",
      "unit": "SEPLAG/SUBGEP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/06/2026 09:56",
      "unit": "SEPLAG/SUPDP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "25/06/2026 16:43",
      "unit": "SEPLAG/SUBGEP",
      "description": "Processo remetido pela unidade SEPLAG/SUBORC"
    },
    {
      "dateTime": "25/06/2026 16:23",
      "unit": "SEPLAG/SUBORC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "25/06/2026 16:05",
      "unit": "SEPLAG/SUBORC",
      "description": "Processo remetido pela unidade SEPLAG/SUPEFIS"
    },
    {
      "dateTime": "24/06/2026 13:36",
      "unit": "SEPLAG/SUPDP",
      "description": "Processo remetido pela unidade SEPLAG/SUBGEP"
    },
    {
      "dateTime": "24/06/2026 13:28",
      "unit": "SEPLAG/SUBGEP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/06/2026 12:35",
      "unit": "SEPLAG/SUBGEP",
      "description": "Processo remetido pela unidade SEPLAG/SUPDP"
    },
    {
      "dateTime": "24/06/2026 10:45",
      "unit": "SEPLAG/SUPDP",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "23/06/2026 14:03",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/06/2026 11:05",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/06/2026 18:14",
      "unit": "SEPLAG/SUPEFIS",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/06/2026 17:51",
      "unit": "SEPLAG/SUPEFIS",
      "description": "Processo remetido pela unidade SEPLAG/SUBAORC"
    },
    {
      "dateTime": "11/06/2026 17:39",
      "unit": "SEPLAG/SUBAORC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/06/2026 17:37",
      "unit": "SEPLAG/SUBAORC",
      "description": "Processo remetido pela unidade SEPLAG/SUBPLO"
    },
    {
      "dateTime": "11/06/2026 14:23",
      "unit": "SEPLAG/SUBPLO",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/06/2026 14:05",
      "unit": "SEPLAG/SUBPLO",
      "description": "Processo remetido pela unidade SEPLAG/CHEGAB"
    },
    {
      "dateTime": "10/06/2026 19:35",
      "unit": "SEPLAG/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "10/06/2026 18:30",
      "unit": "SEPLAG/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "10/06/2026 18:10",
      "unit": "SEEDUC/GABSEC",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "10/06/2026 14:15",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "10/06/2026 14:13",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "10/06/2026 13:20",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "10/06/2026 12:57",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "10/06/2026 11:45",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/ARQDOC"
    },
    {
      "dateTime": "09/06/2026 14:58",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "09/06/2026 14:49",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/ASSUPOF"
    },
    {
      "dateTime": "09/06/2026 12:56",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade FAETEC/CHEGAB"
    },
    {
      "dateTime": "03/06/2026 19:59",
      "unit": "FAETEC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "03/06/2026 15:40",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "02/06/2026 15:46",
      "unit": "SEEDUC/ARQDOC",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "02/06/2026 15:28",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/ARQDOC"
    },
    {
      "dateTime": "02/06/2026 15:27",
      "unit": "SEEDUC/ARQDOC",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "02/06/2026 15:23",
      "unit": "FAETEC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/ARQDOC"
    },
    {
      "dateTime": "02/06/2026 15:22",
      "unit": "SEEDUC/ARQDOC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "02/06/2026 15:03",
      "unit": "SEEDUC/ARQDOC",
      "description": "Processo remetido pela unidade SEEDUC/CHEGAB"
    },
    {
      "dateTime": "02/06/2026 14:17",
      "unit": "SEEDUC/ARQDOC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "02/06/2026 12:35",
      "unit": "SEEDUC/ARQDOC",
      "description": "Processo remetido pela unidade SEEDUC/CHEGAB"
    },
    {
      "dateTime": "21/05/2026 13:22",
      "unit": "SEEDUC/ASSUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "21/05/2026 13:18",
      "unit": "SEEDUC/ASSUPOF",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "21/05/2026 10:39",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "20/05/2026 21:12",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "20/05/2026 18:20",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "20/05/2026 17:41",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/SUPGP"
    },
    {
      "dateTime": "20/05/2026 13:01",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "20/05/2026 12:59",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "20/05/2026 12:54",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "20/05/2026 12:38",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "20/05/2026 12:02",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "20/05/2026 11:51",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/ASSUPOF"
    },
    {
      "dateTime": "15/05/2026 15:36",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "15/05/2026 09:01",
      "unit": "SEEDUC/ASSUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/05/2026 20:05",
      "unit": "SEEDUC/ASSUPOF",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "14/05/2026 13:53",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/05/2026 13:47",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/SUPGP"
    },
    {
      "dateTime": "14/05/2026 13:35",
      "unit": "SEEDUC/SUPGP",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "14/05/2026 13:22",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/05/2026 13:21",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/SUPGP"
    },
    {
      "dateTime": "12/05/2026 23:05",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "12/05/2026 19:48",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "06/05/2026 13:33",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "06/05/2026 13:31",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/ASSUPOF"
    },
    {
      "dateTime": "05/05/2026 17:56",
      "unit": "SEEDUC/ASSUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "05/05/2026 17:50",
      "unit": "SEEDUC/ASSUPOF",
      "description": "Processo remetido pela unidade SEEDUC/SUPOF"
    },
    {
      "dateTime": "05/05/2026 17:48",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "05/05/2026 16:40",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "04/05/2026 19:54",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/NUCSPEA"
    },
    {
      "dateTime": "04/05/2026 12:38",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/04/2026 19:36",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "29/04/2026 15:13",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/04/2026 15:12",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/SUPGP"
    },
    {
      "dateTime": "27/04/2026 16:40",
      "unit": "SEEDUC/NUCSPEA",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/04/2026 15:02",
      "unit": "SEEDUC/NUCSPEA",
      "description": "Processo remetido pela unidade SEEDUC/NUCALC"
    },
    {
      "dateTime": "27/04/2026 14:43",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/04/2026 14:08",
      "unit": "SEEDUC/NUCALC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/04/2026 13:07",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "27/04/2026 13:06",
      "unit": "SEEDUC/NUCALC",
      "description": "Processo remetido pela unidade SEEDUC/ASSJUR"
    },
    {
      "dateTime": "27/04/2026 12:13",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/04/2026 12:11",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/04/2026 11:48",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/04/2026 11:45",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "27/04/2026 11:45",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "27/04/2026 11:45",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "24/04/2026 18:29",
      "unit": "SEEDUC/SUBAD",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "16/04/2026 10:49",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "15/04/2026 18:04",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SECTI/GABSEC"
    },
    {
      "dateTime": "14/04/2026 15:18",
      "unit": "SECTI/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/04/2026 14:11",
      "unit": "SECTI/GABSEC",
      "description": "Processo remetido pela unidade SECTI/ASSJUR"
    },
    {
      "dateTime": "09/04/2026 15:15",
      "unit": "SECTI/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "09/04/2026 14:58",
      "unit": "SECTI/ASSJUR",
      "description": "Processo remetido pela unidade SECTI/GABSEC"
    },
    {
      "dateTime": "09/04/2026 14:25",
      "unit": "SECTI/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "09/04/2026 14:23",
      "unit": "SECTI/GABSEC",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "08/04/2026 14:32",
      "unit": "SEEDUC/SUPGP",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "08/04/2026 11:20",
      "unit": "SEEDUC/SUPGP",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "07/04/2026 16:38",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "07/04/2026 16:01",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade FAETEC/ASSJUR"
    },
    {
      "dateTime": "07/04/2026 11:35",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "06/04/2026 15:05",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "26/03/2026 17:10",
      "unit": "SECC/ASSAL",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "18/03/2026 10:11",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/03/2026 09:40",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SECTI/GABSEC"
    },
    {
      "dateTime": "18/03/2026 09:36",
      "unit": "SECTI/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/03/2026 15:50",
      "unit": "SECTI/GABSEC",
      "description": "Processo remetido pela unidade SECTI/ASSJUR"
    },
    {
      "dateTime": "17/03/2026 15:35",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/03/2026 14:07",
      "unit": "SECTI/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/03/2026 12:58",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/03/2026 12:22",
      "unit": "SECTI/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/03/2026 12:03",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "17/03/2026 11:49",
      "unit": "SECTI/ASSJUR",
      "description": "Processo remetido pela unidade SECC/SUBGEP"
    },
    {
      "dateTime": "17/03/2026 11:49",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo remetido pela unidade SECC/SUBGEP"
    },
    {
      "dateTime": "17/03/2026 11:49",
      "unit": "SECTI/GABSEC",
      "description": "Processo remetido pela unidade SECC/SUBGEP"
    },
    {
      "dateTime": "17/03/2026 10:46",
      "unit": "SECC/SUBGEP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "16/03/2026 17:41",
      "unit": "SECC/SUBGEP",
      "description": "Processo remetido pela unidade SECC/SUBJUR"
    },
    {
      "dateTime": "19/02/2026 11:00",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "12/02/2026 15:40",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SECTI/GABSEC"
    },
    {
      "dateTime": "10/02/2026 16:58",
      "unit": "SECC/SUBJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "10/02/2026 16:54",
      "unit": "SECC/SUBGEP",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "10/02/2026 16:53",
      "unit": "SECC/SUBJUR",
      "description": "Processo remetido pela unidade SECC/SUBGEP"
    },
    {
      "dateTime": "10/02/2026 16:33",
      "unit": "SECC/SUBGEP",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "09/02/2026 09:10",
      "unit": "SECTI/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "06/02/2026 16:30",
      "unit": "SECTI/GABSEC",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "06/02/2026 11:09",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "05/02/2026 16:53",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade FAETEC/DIVRH"
    },
    {
      "dateTime": "30/10/2025 11:56",
      "unit": "SECC/ASSAL",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "31/07/2025 10:52",
      "unit": "SECC/ASSAL",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "06/05/2025 16:30",
      "unit": "RIOPREV/GERCAP",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "24/10/2024 15:04",
      "unit": "FAETEC/DIVRH",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "23/10/2024 15:17",
      "unit": "FAETEC/DIVRH",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "23/10/2024 11:49",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "22/10/2024 17:46",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "22/10/2024 10:48",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "21/10/2024 19:21",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "18/10/2024 18:34",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/10/2024 17:40",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/SUPGP"
    },
    {
      "dateTime": "04/09/2024 13:33",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "04/09/2024 12:31",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "04/09/2024 10:24",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "04/09/2024 10:23",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "03/09/2024 13:00",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "03/09/2024 11:33",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "27/08/2024 16:31",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/08/2024 12:24",
      "unit": "SEEDUC/GABSEC",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "22/08/2024 09:59",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade FAETEC/DIVRH"
    },
    {
      "dateTime": "16/08/2024 13:14",
      "unit": "FAETEC/DIVRH",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/08/2024 22:17",
      "unit": "FAETEC/DIVRH",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "14/08/2024 14:13",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "12/08/2024 15:01",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "31/07/2024 10:54",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "30/07/2024 19:13",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "30/07/2024 13:22",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/07/2024 17:28",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/SUPGP"
    },
    {
      "dateTime": "12/07/2024 13:49",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "12/07/2024 13:29",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "12/07/2024 12:38",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "12/07/2024 12:35",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "10/07/2024 16:27",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "10/07/2024 14:29",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "03/07/2024 16:37",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "03/07/2024 11:13",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SECC/SUBGEP"
    },
    {
      "dateTime": "03/07/2024 11:06",
      "unit": "SECC/SUBGEP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "03/07/2024 10:02",
      "unit": "SECC/SUBGEP",
      "description": "Processo remetido pela unidade SECC/COPRE"
    },
    {
      "dateTime": "28/06/2024 11:24",
      "unit": "SECC/COPRE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "28/06/2024 11:21",
      "unit": "SECC/COPRE",
      "description": "Processo remetido pela unidade SECC/SUPDP"
    },
    {
      "dateTime": "27/06/2024 17:22",
      "unit": "SECC/SUPDP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/06/2024 17:08",
      "unit": "SECC/SUPDP",
      "description": "Processo remetido pela unidade SECC/SUPTEX"
    },
    {
      "dateTime": "21/06/2024 14:30",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "21/06/2024 13:59",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade FAETEC/DIVRH"
    },
    {
      "dateTime": "21/06/2024 13:48",
      "unit": "FAETEC/DIVRH",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "21/06/2024 13:48",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade FAETEC/DIVRH"
    },
    {
      "dateTime": "21/06/2024 12:58",
      "unit": "FAETEC/DIVRH",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "21/06/2024 12:00",
      "unit": "FAETEC/DIVRH",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "20/06/2024 15:39",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/06/2024 14:24",
      "unit": "SECC/ASSAL",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/06/2024 14:07",
      "unit": "SECC/SUPTEX",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/06/2024 14:03",
      "unit": "SECC/SUPTEX",
      "description": "Processo remetido pela unidade SECC/SUBTEX"
    },
    {
      "dateTime": "18/06/2024 14:03",
      "unit": "SECC/SUBTEX",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/06/2024 13:59",
      "unit": "SECC/SUBTEX",
      "description": "Processo remetido pela unidade SECC/CHEGAB"
    },
    {
      "dateTime": "18/06/2024 13:59",
      "unit": "SECC/ASSAL",
      "description": "Processo remetido pela unidade SECC/CHEGAB"
    },
    {
      "dateTime": "14/06/2024 15:01",
      "unit": "SECC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/06/2024 14:43",
      "unit": "SEEDUC/GABSEC",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "14/06/2024 14:32",
      "unit": "SECC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "14/06/2024 14:32",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "04/06/2024 12:30",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "04/06/2024 12:28",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/CHEGAB"
    },
    {
      "dateTime": "04/06/2024 11:45",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "04/06/2024 10:56",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/ASSJUR"
    },
    {
      "dateTime": "29/05/2024 16:57",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/05/2024 16:56",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "29/05/2024 16:34",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "28/05/2024 16:10",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "28/05/2024 10:51",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "28/05/2024 10:39",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/SUPGP"
    },
    {
      "dateTime": "17/05/2024 16:58",
      "unit": "SEEDUC/SUPGP",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "17/05/2024 16:58",
      "unit": "SEEDUC/SUPGP",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "16/05/2024 17:34",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "16/05/2024 17:35",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "16/05/2024 17:13",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "16/05/2024 16:53",
      "unit": "SEEDUC/GABSEC",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "16/05/2024 16:53",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "26/04/2024 14:32",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/04/2024 14:26",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/04/2024 14:27",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/CHEGAB"
    },
    {
      "dateTime": "26/04/2024 13:19",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade PGE/PG15/COO-CSJ"
    },
    {
      "dateTime": "26/04/2024 12:10",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "25/04/2024 20:49",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo remetido pela unidade PGE/PG15/COO-CSJ"
    },
    {
      "dateTime": "25/04/2024 20:36",
      "unit": "PGE/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "25/04/2024 18:54",
      "unit": "PGE/CHEGAB",
      "description": "Processo remetido pela unidade SEFAZ/CHEGAB"
    },
    {
      "dateTime": "25/04/2024 16:27",
      "unit": "SEFAZ/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "25/04/2024 11:11",
      "unit": "SEFAZ/CHEGAB",
      "description": "Processo remetido pela unidade SEFAZ/SUBAPOF"
    },
    {
      "dateTime": "24/04/2024 17:47",
      "unit": "SEFAZ/SUBAPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/04/2024 17:23",
      "unit": "SEFAZ/SUBAPOF",
      "description": "Processo remetido pela unidade SEFAZ/COMISARRF"
    },
    {
      "dateTime": "19/04/2024 12:53",
      "unit": "SEEDUC/CHEGAB",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "19/04/2024 12:54",
      "unit": "SEEDUC/CHEGAB",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "18/04/2024 15:15",
      "unit": "SEFAZ/COMISARRF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/04/2024 15:02",
      "unit": "SEFAZ/COMISARRF",
      "description": "Processo remetido pela unidade SEFAZ/SUBTES"
    },
    {
      "dateTime": "18/04/2024 14:56",
      "unit": "SEFAZ/SUBTES",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/04/2024 14:45",
      "unit": "SEFAZ/SUBTES",
      "description": "Processo remetido pela unidade SEFAZ/CHEGAB"
    },
    {
      "dateTime": "18/04/2024 13:58",
      "unit": "SEFAZ/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/04/2024 12:21",
      "unit": "SEFAZ/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/04/2024 12:21",
      "unit": "SEFAZ/CHEGAB",
      "description": "Processo remetido pela unidade SEFAZ/GABSEC"
    },
    {
      "dateTime": "17/04/2024 19:01",
      "unit": "SEFAZ/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "19/03/2024 13:17",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "19/03/2024 12:02",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "18/03/2024 16:09",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/03/2024 13:00",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade FAETEC/ASSJUR"
    },
    {
      "dateTime": "21/02/2024 10:27",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "20/02/2024 17:27",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "30/01/2024 16:39",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/01/2024 11:50",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SECTI/CHEGAB"
    },
    {
      "dateTime": "26/01/2024 11:34",
      "unit": "SECTI/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/01/2024 10:59",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SECC/SUBTEX"
    },
    {
      "dateTime": "26/01/2024 10:59",
      "unit": "SECTI/CHEGAB",
      "description": "Processo remetido pela unidade SECC/SUBTEX"
    },
    {
      "dateTime": "26/01/2024 10:49",
      "unit": "SECC/SUBTEX",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "25/01/2024 19:13",
      "unit": "SECC/SUBTEX",
      "description": "Processo remetido pela unidade SECC/CHEGAB"
    },
    {
      "dateTime": "18/01/2024 17:40",
      "unit": "SECC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/01/2024 17:20",
      "unit": "SECC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "18/01/2024 11:05",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/01/2024 16:55",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/ASSJUR"
    },
    {
      "dateTime": "17/01/2024 14:24",
      "unit": "FAETEC/ASSJUR",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "12/12/2023 17:59",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "12/12/2023 17:01",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "08/12/2023 11:36",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "08/12/2023 11:36",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/CHEGAB"
    },
    {
      "dateTime": "08/12/2023 11:34",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "07/12/2023 18:01",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade SECC/CHEGAB"
    },
    {
      "dateTime": "07/12/2023 11:38",
      "unit": "SECC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "07/12/2023 11:26",
      "unit": "SECC/CHEGAB",
      "description": "Processo remetido pela unidade SECC/SUPDP"
    },
    {
      "dateTime": "30/11/2023 15:18",
      "unit": "SECC/SUPDP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "30/11/2023 09:49",
      "unit": "SECC/SUPDP",
      "description": "Processo remetido pela unidade SECC/SUBGEP"
    },
    {
      "dateTime": "30/11/2023 09:47",
      "unit": "SECC/SUBGEP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "30/11/2023 09:19",
      "unit": "SECC/SUPDP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/11/2023 16:11",
      "unit": "SECC/SUPDP",
      "description": "Processo remetido pela unidade SECC/CHEGAB"
    },
    {
      "dateTime": "29/11/2023 16:11",
      "unit": "SECC/SUBGEP",
      "description": "Processo remetido pela unidade SECC/CHEGAB"
    },
    {
      "dateTime": "29/11/2023 15:27",
      "unit": "SECC/ASSOC",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "29/11/2023 12:00",
      "unit": "SEEDUC/SUBEXE",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "29/11/2023 11:04",
      "unit": "SECC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/11/2023 10:39",
      "unit": "SECC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "29/11/2023 09:53",
      "unit": "SEEDUC/SUBEXE",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "24/11/2023 12:49",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/11/2023 12:13",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "24/11/2023 12:03",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/11/2023 12:02",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/SUPOF"
    },
    {
      "dateTime": "24/11/2023 12:01",
      "unit": "SEEDUC/SUPOF",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "21/11/2023 12:21",
      "unit": "SEEDUC/SUPOF",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "21/11/2023 12:20",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "21/11/2023 12:12",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo remetido pela unidade SEEDUC/ASSCONT"
    },
    {
      "dateTime": "08/11/2023 15:00",
      "unit": "SEEDUC/ASPLO",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "08/11/2023 12:38",
      "unit": "SEEDUC/ASSCONT",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "08/11/2023 12:38",
      "unit": "SEEDUC/ASPLO",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "08/11/2023 10:23",
      "unit": "SEEDUC/ASPLO",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "08/11/2023 10:23",
      "unit": "SEEDUC/ASSCONT",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "07/11/2023 12:12",
      "unit": "SEEDUC/SUBAD",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "07/11/2023 10:46",
      "unit": "SEEDUC/SUBAD",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "06/11/2023 10:19",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "04/11/2023 01:08",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "01/11/2023 20:31",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "01/11/2023 20:31",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "01/11/2023 13:06",
      "unit": "SEEDUC/SUBAD",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "01/11/2023 13:05",
      "unit": "SEEDUC/SUBAD",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "31/10/2023 10:49",
      "unit": "SEEDUC/SUPGP",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "27/10/2023 14:44",
      "unit": "SEEDUC/SUBEXE",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "27/10/2023 14:26",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/10/2023 13:47",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/SUPOF"
    },
    {
      "dateTime": "27/10/2023 13:40",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/10/2023 12:04",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo remetido pela unidade SEEDUC/ASSCONT"
    },
    {
      "dateTime": "26/10/2023 15:51",
      "unit": "SECC/SUPDP",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "26/10/2023 14:32",
      "unit": "SEEDUC/SUBEXE",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "26/10/2023 14:32",
      "unit": "SEEDUC/SUBEXE",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "26/10/2023 14:25",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/10/2023 14:25",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "26/10/2023 14:04",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/10/2023 13:31",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/SUPOF"
    },
    {
      "dateTime": "25/10/2023 14:49",
      "unit": "RIOPREV/GERBE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/10/2023 17:36",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/10/2023 17:34",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo remetido pela unidade SEEDUC/ASSPLAG"
    },
    {
      "dateTime": "24/10/2023 14:01",
      "unit": "SEEDUC/ASPLO",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/10/2023 12:32",
      "unit": "SEEDUC/ASSCONT",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/10/2023 11:41",
      "unit": "SEEDUC/GABSEC",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "24/10/2023 11:38",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/10/2023 11:22",
      "unit": "SEEDUC/ASPLO",
      "description": "Processo remetido pela unidade SEEDUC/SUPOF"
    },
    {
      "dateTime": "24/10/2023 11:22",
      "unit": "SEEDUC/ASSCONT",
      "description": "Processo remetido pela unidade SEEDUC/SUPOF"
    },
    {
      "dateTime": "24/10/2023 09:38",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "23/10/2023 21:48",
      "unit": "SEEDUC/ASSCONT",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "23/10/2023 17:47",
      "unit": "SEEDUC/ASSCONT",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "23/10/2023 17:47",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "23/10/2023 16:24",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "23/10/2023 16:10",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "23/10/2023 16:03",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "23/10/2023 16:03",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "23/10/2023 16:03",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "23/10/2023 16:03",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "23/10/2023 16:03",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "18/10/2023 10:28",
      "unit": "RIOPREV/GERBE",
      "description": "Processo remetido pela unidade RIOPREV/DIRSE"
    },
    {
      "dateTime": "17/10/2023 16:57",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/10/2023 12:21",
      "unit": "RIOPREV/DIRSE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/10/2023 12:13",
      "unit": "RIOPREV/DIRSE",
      "description": "Processo remetido pela unidade SECC/SUBGEP"
    },
    {
      "dateTime": "17/10/2023 12:13",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SECC/SUBGEP"
    },
    {
      "dateTime": "17/10/2023 11:58",
      "unit": "SECC/SUBGEP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/10/2023 11:21",
      "unit": "SECC/SUBGEP",
      "description": "Processo remetido pela unidade SECC/COGIC"
    },
    {
      "dateTime": "17/10/2023 10:03",
      "unit": "SECC/COGIC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/10/2023 09:50",
      "unit": "SECC/COGIC",
      "description": "Processo remetido pela unidade SECC/SUPDP"
    },
    {
      "dateTime": "10/10/2023 15:11",
      "unit": "SEEDUC/SUBAD",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "05/10/2023 16:38",
      "unit": "SECC/SUPDP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "05/10/2023 12:15",
      "unit": "SECC/SUPDP",
      "description": "Processo remetido pela unidade SECC/SUBGEP"
    },
    {
      "dateTime": "05/10/2023 12:12",
      "unit": "SECC/SUBGEP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "04/10/2023 11:22",
      "unit": "SECC/SUBGEP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "28/09/2023 19:23",
      "unit": "RIOPREV/DIRSE",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "28/09/2023 18:12",
      "unit": "RIOPREV/DIRSE",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "20/09/2023 12:10",
      "unit": "FAETEC/CHEGAB",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "18/09/2023 11:26",
      "unit": "SEEDUC/SUBAD",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "18/09/2023 09:27",
      "unit": "FAETEC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "15/09/2023 13:58",
      "unit": "RIOPREV/GERBE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "15/09/2023 11:59",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "15/09/2023 11:30",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/09/2023 16:26",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "14/09/2023 16:26",
      "unit": "FAETEC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "14/09/2023 16:26",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "14/09/2023 16:26",
      "unit": "RIOPREV/GERBE",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "28/08/2023 14:22",
      "unit": "SECC/ASSOC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "28/08/2023 12:30",
      "unit": "SECC/ASSOC",
      "description": "Processo remetido pela unidade SECC/SUPTEX"
    },
    {
      "dateTime": "23/08/2023 15:51",
      "unit": "RIOPREV/DIRSE",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "17/08/2023 12:03",
      "unit": "RIOPREV/GERBE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/08/2023 11:29",
      "unit": "RIOPREV/GERBE",
      "description": "Processo remetido pela unidade RIOPREV/DIRSE"
    },
    {
      "dateTime": "16/08/2023 10:05",
      "unit": "RIOPREV/DIRSE",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "10/08/2023 14:46",
      "unit": "SEEDUC/SUBAD",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "09/08/2023 15:17",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "09/08/2023 13:12",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "08/08/2023 17:48",
      "unit": "RIOPREV/GERPA",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "08/08/2023 08:26",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "07/08/2023 16:57",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "07/08/2023 15:53",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "04/08/2023 17:12",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "01/08/2023 12:36",
      "unit": "FAETEC/PRESI",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "25/07/2023 08:18",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/07/2023 14:09",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "19/07/2023 11:46",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "19/07/2023 11:43",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "19/07/2023 10:33",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "18/07/2023 12:29",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "17/07/2023 16:44",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/07/2023 16:33",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/SUPOF"
    },
    {
      "dateTime": "14/07/2023 15:51",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "13/07/2023 18:04",
      "unit": "SEEDUC/SUPOF",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "13/07/2023 17:47",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "13/07/2023 16:24",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "13/07/2023 13:31",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "12/07/2023 16:20",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "12/07/2023 15:31",
      "unit": "SEEDUC/SUBAD",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "30/06/2023 16:49",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "30/06/2023 16:44",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "30/06/2023 14:01",
      "unit": "SEEDUC/SUPGP",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "30/06/2023 11:12",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "30/06/2023 10:24",
      "unit": "RIOPREV/GERPA",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "30/06/2023 10:21",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade RIOPREV/DIRSE"
    },
    {
      "dateTime": "30/06/2023 10:21",
      "unit": "RIOPREV/GERPA",
      "description": "Processo remetido pela unidade RIOPREV/DIRSE"
    },
    {
      "dateTime": "30/06/2023 08:40",
      "unit": "RIOPREV/DIRSE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/06/2023 18:41",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "29/06/2023 17:30",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/06/2023 17:16",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade FAETEC/DIVRH"
    },
    {
      "dateTime": "29/06/2023 17:11",
      "unit": "FAETEC/DIVRH",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/06/2023 16:04",
      "unit": "RIOPREV/DIRSE",
      "description": "Processo remetido pela unidade RIOPREV/PRESI"
    },
    {
      "dateTime": "29/06/2023 15:46",
      "unit": "FAETEC/PRESI",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "29/06/2023 14:52",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/06/2023 14:49",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade FAETEC/ASSJUR"
    },
    {
      "dateTime": "29/06/2023 10:21",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "29/06/2023 08:29",
      "unit": "FAETEC/CHEGAB",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "29/06/2023 08:28",
      "unit": "FAETEC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "28/06/2023 19:32",
      "unit": "FAETEC/ASSJUR",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "28/06/2023 19:32",
      "unit": "FAETEC/DIVRH",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "28/06/2023 19:32",
      "unit": "FAETEC/CHEGAB",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "28/06/2023 16:46",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "28/06/2023 15:44",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/06/2023 17:00",
      "unit": "SECC/SUPTEX",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/06/2023 16:59",
      "unit": "SECC/SUPTEX",
      "description": "Processo remetido pela unidade SECC/SUBTEX"
    },
    {
      "dateTime": "27/06/2023 16:56",
      "unit": "RIOPREV/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/06/2023 16:55",
      "unit": "SECC/SUBTEX",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/06/2023 16:53",
      "unit": "SECC/SUBTEX",
      "description": "Processo remetido pela unidade SECC/CHEGAB"
    },
    {
      "dateTime": "27/06/2023 16:18",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/06/2023 16:11",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/06/2023 15:59",
      "unit": "SECC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/06/2023 15:55",
      "unit": "SEEDUC/SUBAD",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "27/06/2023 15:50",
      "unit": "RIOPREV/PRESI",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "27/06/2023 15:50",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "27/06/2023 15:50",
      "unit": "SECC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "27/06/2023 15:50",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "27/06/2023 15:50",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "27/06/2023 15:50",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "27/06/2023 15:34",
      "unit": "SEEDUC/SUBAD",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "27/06/2023 13:29",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/06/2023 13:29",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "26/06/2023 15:56",
      "unit": "RIOPREV/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "26/06/2023 13:27",
      "unit": "RIOPREV/PRESI",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "21/06/2023 13:11",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "21/06/2023 09:56",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUPTA"
    },
    {
      "dateTime": "16/06/2023 16:46",
      "unit": "SEEDUC/SUPTA",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "16/06/2023 10:09",
      "unit": "SEEDUC/SUPTA",
      "description": "Processo remetido pela unidade SEEDUC/PROTPUB"
    },
    {
      "dateTime": "14/06/2023 15:27",
      "unit": "SEEDUC/PROTPUB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "14/06/2023 15:24",
      "unit": "SEEDUC/PROTPUB",
      "description": "Processo remetido pela unidade SEEDUC/SUPTA"
    },
    {
      "dateTime": "08/06/2023 22:36",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "07/06/2023 18:04",
      "unit": "SEEDUC/SUPTA",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "07/06/2023 17:35",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "07/06/2023 17:35",
      "unit": "SEEDUC/SUPTA",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "01/06/2023 12:45",
      "unit": "SEEDUC/CHEGAB",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "01/06/2023 12:06",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "31/05/2023 16:47",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "29/05/2023 12:32",
      "unit": "FAETEC/PRESI",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "29/05/2023 12:30",
      "unit": "FAETEC/PRESI",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "24/05/2023 16:10",
      "unit": "SECC/SUBG",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "24/05/2023 12:05",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "24/05/2023 11:51",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/ASSJUR"
    },
    {
      "dateTime": "22/05/2023 09:50",
      "unit": "SEEDUC/SUPGP",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "19/05/2023 10:34",
      "unit": "SEEDUC/SUBEXE",
      "description": "Conclus�o do processo na unidade"
    },
    {
      "dateTime": "17/05/2023 15:07",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "17/05/2023 10:47",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "17/05/2023 10:36",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "17/05/2023 10:27",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "16/05/2023 16:04",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade FAETEC/PRESI"
    },
    {
      "dateTime": "16/05/2023 09:58",
      "unit": "SECC/SUBG",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "15/05/2023 18:41",
      "unit": "SECC/SUBG",
      "description": "Processo remetido pela unidade SECC/CHEGAB"
    },
    {
      "dateTime": "12/05/2023 17:29",
      "unit": "SECC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "12/05/2023 14:13",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "12/05/2023 12:07",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "12/05/2023 12:07",
      "unit": "SECC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "12/05/2023 12:05",
      "unit": "SECC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/05/2023 18:24",
      "unit": "FAETEC/PRESI",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/05/2023 18:07",
      "unit": "FAETEC/PRESI",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "11/05/2023 18:07",
      "unit": "SECC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/GABSEC"
    },
    {
      "dateTime": "11/05/2023 13:35",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/05/2023 11:50",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/05/2023 11:11",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/05/2023 11:06",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "11/05/2023 11:05",
      "unit": "SEEDUC/SUPGP",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "11/05/2023 11:02",
      "unit": "SEEDUC/ASSJUR",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "11/05/2023 11:02",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "11/05/2023 11:02",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/SUBAD"
    },
    {
      "dateTime": "08/05/2023 11:33",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "08/05/2023 11:01",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "08/05/2023 11:01",
      "unit": "SEEDUC/GABSEC",
      "description": "Processo remetido pela unidade SEEDUC/CHEGAB"
    },
    {
      "dateTime": "08/05/2023 11:01",
      "unit": "SEEDUC/CHEGAB",
      "description": "Reabertura do processo na unidade"
    },
    {
      "dateTime": "08/05/2023 10:59",
      "unit": "SEEDUC/SUBAD",
      "description": "Processo remetido pela unidade SEEDUC/CHEGAB"
    },
    {
      "dateTime": "04/05/2023 12:19",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "03/05/2023 19:04",
      "unit": "SEEDUC/CHEGAB",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "03/05/2023 16:50",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "03/05/2023 12:55",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo remetido pela unidade SEEDUC/SUPTA"
    },
    {
      "dateTime": "02/05/2023 10:04",
      "unit": "SEEDUC/SUPTA",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "02/05/2023 09:36",
      "unit": "SEEDUC/SUPTA",
      "description": "Processo remetido pela unidade SEEDUC/PROTPUB"
    },
    {
      "dateTime": "27/04/2023 18:52",
      "unit": "SEEDUC/PROTPUB",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/04/2023 18:06",
      "unit": "SEEDUC/PROTPUB",
      "description": "Processo remetido pela unidade SEEDUC/SUPTA"
    },
    {
      "dateTime": "27/04/2023 12:10",
      "unit": "SEEDUC/SUPTA",
      "description": "Processo recebido na unidade"
    },
    {
      "dateTime": "27/04/2023 12:08",
      "unit": "SEEDUC/SUPTA",
      "description": "Processo remetido pela unidade SEEDUC/SUBEXE"
    },
    {
      "dateTime": "17/04/2023 15:29",
      "unit": "SEEDUC/SUBEXE",
      "description": "Processo p�blico gerado"
    }
  ],
  "documents": [
    {
      "number": "50446540",
      "type": "Despacho de Encaminhamento de Documento",
      "date": "17/04/2023",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1ZuccKtiiT8_6aBRvM7Ts-Ag0PJgQmC6OY4i05FXYMT7hJxv3pg84oE6Hpz_TvZ7Vcan9QESw_iPR3pMPWeNDg",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51033843",
      "type": "Minuta de Resolu��o",
      "date": "27/04/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3rE5TarKn7KiSgImLy7QvAmLGf5Eu8F5C_jY-Aox6t3ZkWJIKf-RocfIdLrujHmo646uVSx8pTuYwdbtFI7o8Z",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51034274",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/04/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2SFTXjdOk2_PF0fSMNrz-2csYuwvUJD-2jj71GDmwVVsbTRnmEXmZin9Zc3-b2CRPmqVY4qMrRiisn0CNSsdVx",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51036367",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/04/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0X1dZkZqNbSWXxT68J9SEXvZlabZekUju3_aNAPZ5YBvsuU16fEqiCrsvmH0qqAFKG_gV6oPwa_rjBrWSeKzrH",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51035761",
      "type": "Resolu��o - NI 6164",
      "date": "27/04/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2pBXk0Zh5SCnnbDy5vIRDdCdGpcNfKJCQJrp7quVHhC46OgDd393fs6cw-M3IMfM0gVUF15M-EUNM-5B1ng0Zp",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51032515",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/04/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0uW0uQAs7H2dv80lWT8eBEVYdS4y63lXyv9AYcSUHvBVGowuYiz3_7-1un5yMWk5Lx6gRnKBWaScZSVqyx3P2Q",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51080925",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/04/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj16k2iugUiuXt6pIvsv6__D_vQ0QL2DOLsronS0GzNXwDt8EcOE8ugQACC3X6Y591X1Naq9dJ4CdblMM7ySEAU0",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51188395",
      "type": "Publica��o D.O. 02/05/2023",
      "date": "02/05/2023",
      "unit": "SEEDUC/PROTPUB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2A2Zoc5ntBkDq2Fl0IZawnCAcphRJhCcYhUT-dwPXKFAs2kJQBcbrUHrLQHn2HcAMmOtIqxJF7JdKb1AeDieMO",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51197239",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "03/05/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2ZWoxhTGwgk3dB1_AGCbx0VEEH6A7Da2GcQMqHg-hFfqpqrwnFjjQxBDDFtsxviQl_xmbVk_aJdxuSAu0JJGCS",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51363035",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "03/05/2023",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3WE4SA0rld1A_8OApmYVqhtHykfuZt1cED1kKHPzc1mHN2wUujyuNmJYiEbpM-HlAQ33GwKvt-qgRdaVC_dmyP",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51566701",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "08/05/2023",
      "unit": "SEEDUC/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1hTLOyicR6v1SPI7rl_B9vcWZ4CI5_PePR_Nf4M_xd0jpL89USUBjR7wfbUb2hFDLo_Xee_ZUqwa09SJBMJapt",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51779520",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "10/05/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0BlufGfSxAheh4LDaPxG27lOiZ-jfajH3-0pJCj7Ho-QQGFEuyYxo_BalktUic_8LkTejmc2_RkiovbTIRZGfv",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51839308",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "11/05/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0D92cOHqAQd1WWzRffLXNueevC9Aj74zrkozoFA-XLnW5Whlfw1QXK2k_-WF8nfV3QuMpBXC0quoa69QbDFiDA",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51850606",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "11/05/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1uDgzLvgJsR28RwmQCuT2ccPdgff74bvFp8nnc-rmKMAtRzDjFVHrsYQhAblBK-w2Ryg-r1jTaLohqP5QX2qKZ",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51889028",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "12/05/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0yyHCnMtsBB0CHKO8LooEkdtw22fuapAGhnGJllxhkZ8KWlrPkGeP-W9cvHTexrCjSxymjQ1TmDLSTP93RqTaF",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51889256",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "12/05/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1JmzxS4Faqwr23OuAJa6YnkxIj_r78E5ixMTGKZqpMLmi_NZzYx8Qmjt2WO0soksphUHIt_hHoSCBgSAwXRuZ3",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "51971088",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "23/05/2023",
      "unit": "SEEDUC/ASSJUR",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3CqHIwr2NP-E5PWjKJKjGrI3A-igEyQasbigDvDsyRAvIV1r5nJ6gczT0KsLwCx16pOqwzOwVl_FO4zJCsD7D-",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "52044003",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "15/05/2023",
      "unit": "SECC/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3aoIo5iS8cm5NotTUsH60ismEZiFV6N_rMauv3UluOCV-sunGBIfoiGmX6cd6BcisYicMJAobFJphfHCZtyGrf",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "52107624",
      "type": "Of�cio - NA 519",
      "date": "16/05/2023",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2vfT1bMv_Ov3inAzgUQ3Zuvexri2Df0nSGaTSnzY4JWefl6vKj_9jUD10KNVuEI5KKCle3Oh56ZQvXNpV31Hqv",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "52155965",
      "type": "Anexo E-mail Excec Rio",
      "date": "17/05/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1YKq0vbmItVebczs36tYW9lbtXyUD0YYvNPU1gpTOug7jxmqmMQ6Jg3jSZ2wJNG4EqImYYffoKrkZHqZ_wdrAR",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "52155966",
      "type": "Anexo OF 057 - SEPE -INDICA��O GT FAEP",
      "date": "17/05/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0CFTl-OpsMmCBao4sKv0uv74Bg8GPtqDis-n3kl30GkIEoUMux7yRxGnt8TIvlOEX9BiA1EwmG-1PmmXl4PV07",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "52156424",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "17/05/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj19jfTgutglXCTRq81PVYY9tT9s5sOo68t3NTJkEn2daVwyUz2ns0_N8dfWTfvTpY4LRY6wmfkGQrI5YBAs5S2p",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "53057773",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "31/05/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj25TW_q8wiTs0eLb_I7JYHgdgtqxfEP9CISGp8Ne2BrprD01XtpiaD8nypEeVqezOeurtWFrQ69k39w-8KPyy7K",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "53444279",
      "type": "Of�cio - NA 308",
      "date": "07/06/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj09MRDSWxoeV3qqW-FbtjxXqTKQKlR-U-KOizBa5XhdMOPZbVrVMOPlZMXjP0k5y0LZW2s8fpFvwbJZD-t5UnMO",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "53556694",
      "type": "Minuta de Resolu��o",
      "date": "07/06/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1M4SF-vlZUsYCHvZ8QBKxnFiFxzIu9mLQVi6lqSgPWG66QunZFYEcUGteEzSLdbt2QA0FY0Jw9epBSnqABQkT1",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "53567559",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "07/06/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1YuBAsjILtkXX6vaD1HAggjUOfrVIO8llyyIpfqJ1H37F_jg52APYyWcRd-_X5VIFpJrkCmNylGtTuE1MUopgT",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "53729500",
      "type": "Resolu��o - NI 6174",
      "date": "13/06/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3bbHU4XQvFqN2a-Hvat_q4yV902timFY1r2R4ypwXKhCLqBnXsOzr3GxJ5nXDMo8vAu6-3A0MSdBatZ_-VM_Qg",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "53783707",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "14/06/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0SwtuLuEWmwrYwjXKxiudtj3utj2lQwp5VTERcqpgoV08Z45Ap-dglWMwIHZVM9qwK58sTTQr_k-1FrwGmht7s",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "53967062",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "16/06/2023",
      "unit": "SEEDUC/PROTPUB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0L8PGpNkLxu3NEDT4MkmgU5YhGlJ-KDEkzkEIfJcZjU6nPfG1ljGaA6psSGaTAcKs5fPKeokd-Kd6MA9Unfxje",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54045924",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "20/06/2023",
      "unit": "SEEDUC/SUPTA",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1sglJ_7gxx96ZcqXSw2l9t5vGKRmbZtfVBWPLxXpwLv5mpM8VJDxo0Uvox2f1mz-hwtaRhkKk2BTnUnUikr7ja",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54474957",
      "type": "Of�cio - NA 354",
      "date": "26/06/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2Fw8HP07MJGNz5AAki9e6Af68MPnBBXwCcFYtK8rhL-6E1f0nlo1liSu5fpQTtqqEF1kcqhc-bIk5OfErYvihV",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54669438",
      "type": "Of�cio - NA 650",
      "date": "27/06/2023",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0MmPbenT7kSKnUJhHQ3P86v1ABuKZIgTl33-cd7HlT5S5BM4smqEkdSEMeS3R3f1E3TABnB0wmfxY2fJEU5pfz",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54694316",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/06/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1mAti4MT-kA9VNl1Y_MgIBBs61_r0zVlIv3CW6s_qVERy4bD5z1M6Lm9db6By3Zzskjay2zSfaja7oL5CqIXVr",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54697641",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/06/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj39qa5TLljlOdamDdMdWzM7ihSi9lIHfRAv4IXZNE-Z8VwAl59kpEU_X9H4iwhqP5NfsQsLqT8WUOJSuHAyoSmH",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54700109",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/06/2023",
      "unit": "SECC/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj06xYgrg7vdCacOfSW31ddjF8qPMscoDkvB8Q_Aqc7ZQoUCClN2ypT9-Ye-a4KbB8y_hGc0xkMqdqFoD50XnjZ_",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54801212",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "28/06/2023",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj30QdDguMS1jgpWRC6A3ZpNKThel0Sei0pcDucztZ-Jtt9j1AgsyGqhkhCZWzAfqbGb9t9Hrj0vL6tRpFX8Ja8O",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54857274",
      "type": "Of�cio - NA 40",
      "date": "29/06/2023",
      "unit": "FAETEC/ASSJUR",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj31-pT8MflQLTBPwGzsPVhv7FXX5L6WY6KW9vHq2QDbnvTX0vBHKCKloIjBqD7x-wlp_4Eqpvfw2NIdxaVYFRAA",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54870584",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "29/06/2023",
      "unit": "RIOPREV/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2aY8Bf0EPTkpwBeNwGTuwPR4phNio8X_Kzi7Xm1Tk7cIVkbUFAu1OX7ZY6686xHMoHy1fMCG827XZ5x8jo8MBw",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54879958",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "29/06/2023",
      "unit": "FAETEC/DIVRH",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj28EBPQSm6kw9DaE8k4F5Bqx_w1iUZspu415XigJNWLIZOVXmKhIOhfl8tXM-kzjhfd8FO0PIgupuT8gC16iuLm",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54880455",
      "type": "E-mail",
      "date": "29/06/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1f9AKTPeDOATxtWcTryCoKa8BQ5aJZDLD6A4f0rygvHLxthaZ1-mqZtestfwFSjvSSsf_TyB6bk_VU5oF4LOmE",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54880211",
      "type": "Anexo",
      "date": "29/06/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0xAfKaLO2Tu_X1X57KR82wzU2l9tho0r2l72iQzcGmzk9-3nfSw8jpiY9DKH4krJWVTuHm082nq9xSLgrMsC7M",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54882076",
      "type": "Of�cio - NA 664",
      "date": "29/06/2023",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1aPH3qBOSWQ31Wumdm6VEh7TRHUatNX8bamEqhj0K8z3v9O4AeZkxu-m8gNQbRbexTy-ozkoP_Gq23_ovl0_nW",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54899175",
      "type": "Of�cio - NA 140",
      "date": "30/06/2023",
      "unit": "RIOPREV/DIRSE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0MadywZ2nnXLcomHewQDmEETXYlYFr655AUoIs_3IXd-XuuGpypoVT56_-MHQ2FUuXKRsrc9fr9MQ4zfhFPVGk",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "54963570",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "30/06/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj10wbJKbsFvkBt9WOTkjzN70N69622r5qRKjswKhuXjlQfYVgFqaVmOVXDyFFmgvORlKHH9CewfR6620pMIbm4T",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "55663408",
      "type": "Despacho",
      "date": "12/07/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0M_-hySSTzeVjqSxsVwoZezXBE3xmJfww0Q17CLSUmqhpZhxQ0zFzijTlyuZCnOyECfmQWbxcvpokHHWhLAjIs",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "55751112",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "13/07/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj28u_hn7spVDKhQ3QtaUv61e5wiMPQX4dsEOqhZdMvpmgO1kKzbhzMGRGeLB79Drcg_bDK-FpiqUamVrX7kP5jg",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "55766532",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "13/07/2023",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1fOpXAsrdgRLoXrBi6LHfO0aQCLyPf6Fj6HAcS6AM4yAZePAcEBJCd8G7L_3dcJjID17iPsOVSZw85ezHwTIut",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "55833832",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "14/07/2023",
      "unit": "SEEDUC/SUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0pHxDd1OqMVEh0gPdUgltzHGez8QQwOvYdKXytK-ls_9VeFtO1RFpi_jouD7dH2N3cdlwnCLi6CwGOxe_CpOhU",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "55932333",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "18/07/2023",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1vaBUOea37llEIHz8SvpkEzVRiMUh1fKqEA5yR1AI1luGMuEnAxWLzfrGRMzj0rm2ZcuiMRv1pp50O99oQGcK-",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "56060922",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "19/07/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1z-g14cDVwffVbi8TppDIznkuaWjfOzOiLQrn0rGuz8hIZlp_RvJ4C-0a4upTYdnHPZ7OtT69Cr5XkC8UfTg4e",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "56214903",
      "type": "Despacho",
      "date": "21/07/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0PbWjLWS6he-ljz3zscgXsRjqHLY26eQeR5ZAEOLeHYOzaxeuo0rP195iA-IldiDRfHyN7GvsgwvNoaGzqadAz",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "56830629",
      "type": "Of�cio - NA 749",
      "date": "04/08/2023",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3iWRpcDTmj0N05JBx1q9GHsMgkEWi66RVHg8DfWRvFuJVb0SoIofnUdgm8r4QR87BCeHQ0CMfI187orvxi5BdD",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "57205456",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "07/08/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0UVLT6WCAkwFXg-GXNdPXvz4uOKRPHn3eJ2v4JvKvsC6FBry15vhHO078nYYyit_F6QpsqxxkirbZov6giM53q",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "57332885",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "09/08/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2m-qqlOvoIVMgZDb5Q695YE-qeaRRDLGu1nvuEtQNJJU82NrD1VXn5WqNj15xOdelSsYAtqJgZSole5Mvkqnmd",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "57449997",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "10/08/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj104R_3FcbS7F2DLf5dyNXlBymAuBi-0-TfuUN_RGJ52_NKshR0uIMujyQs_hdALI4KQt0GT4eGeh4P70cQDCiT",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "57456783",
      "type": "Relat�rio",
      "date": "10/08/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "57456824",
      "type": "Lista",
      "date": "10/08/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0VYaIuQsPoAoExDyzOAgdgUHOPJm_7OLnJZX2FdxdA9OwyQHaXweEXoIYGE7fPCQyGr3QiHd00l0angTCrwUQm",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "57875665",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "17/08/2023",
      "unit": "RIOPREV/DIRSE",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "59514806",
      "type": "Documento",
      "date": "13/09/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3AvwgFDLOpOp27yRg1LfH-5m-HcD7hoPjUERZvcbI_ICNJ-6j4joDCaVyb1vRlRzhbOtvPcSBMv0Kzg0xp5hUM",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "59516134",
      "type": "Despacho",
      "date": "13/09/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0wVx61P3xoMTn22FAW0XaVCgCTXnO0uY5w4DdnLvAy_yOT8zPZvsBqJazwM0Wcnv4exj2IBCnFJe-pPG7tV2TL",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "59786832",
      "type": "Of�cio",
      "date": "18/09/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3gOrjB6a9lxxAfzdc7dJrey9-a03VZ2lwHEZgiWeZwNCn0ybkJ7PNeDF02MfOk8BaiQnGJrNVozYlv528qnIuC",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "59788667",
      "type": "Despacho",
      "date": "18/09/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0SajRpvfxmLPF1fbfJcA7HVtaYzT3WyUcq0u5l-EoZz0tNUXZOi9ED6Bn79pdKjMWpMUMlo5s9W2ifAVT6tNJp",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "60352278",
      "type": "E-mail",
      "date": "26/09/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1K258vD6RD4nFiyduIiPna9txjYd25335OqT6Qqnd3tx6UTD0KYW5na2AlI7FQUatY3NojlykBONIqR860mMOw",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "60429890",
      "type": "Despacho",
      "date": "18/10/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj01ttfF-F1MY1_xBemm8X5ftKm8ZK7CfeIT86WMIyurQ-SqXSfCGcdiRydemUpnc4ZNilLQxIFH_lX7cG1nG65K",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "60584818",
      "type": "Nota T�cnica",
      "date": "28/09/2023",
      "unit": "RIOPREV/DIRSE",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "60908175",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "04/10/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1mW2hnwlHCV339K8SiwqS-EOWd9rFUexPXYhpvqGADKRAChcjR3iykpYIJcgPy_m7O_s5MJIwNU6uqTqjxnQKt",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "61006318",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "05/10/2023",
      "unit": "SECC/SUBGEP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0KoMclJnuDjBWtIAKm-LBifVMuQHTD1O8xRPqd0Mu1AuB3_JMz-mM3-nOvYlQtUMEKPT0snRG11yrTs4fCn2k1",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "61568455",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "17/10/2023",
      "unit": "SECC/COGIC",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "61590632",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "17/10/2023",
      "unit": "SECC/SUBGEP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1ObHE9ySrK7bbuQv9fsOhV_bLYxpSBxU9F87FDyrmmUZrFCFjRasuVsIufmuE5xlohrFtc3jkfqtLbephLkyKb",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "61666798",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "18/10/2023",
      "unit": "RIOPREV/DIRSE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0oAakfj3DJBhrX6f24iPtStNr_Vls9X832RcHSZf2a9zFgczI-wO44KypBLmHGGruauEcANkpYbY4Ik3Irnjiu",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "61998048",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "23/10/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2Sy3Fx4vbJiltIyNDoBIi32NroURboh3oyqvD5_sG6GU2xcV3uktKwZnM82DNs-VGmJnbJE0xjkNhKOAsAHOMi",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62005512",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "23/10/2023",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0L60B6f78QAQ1tuFKziVOzUDegr47rQhnhmdqpva3lwsucoA_mpxGgMbjdo56LReKojfmyRrraSTqbxFeLhDKH",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62046059",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "24/10/2023",
      "unit": "SEEDUC/SUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2WboH2eYdZYhULsUIrxAeHAv30dzpJTQ-Osv5Cc_GPgGSWhfd7R8KrjCpe_nBAEEf7uf3Sax2dwFYBtb1biMVA",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62107781",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "24/10/2023",
      "unit": "SEEDUC/ASPLO",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3UCEcRrmRyKjVygkleI0xI4imImLgkh_IZ_fJcpna9OZxNmEQKRIqBRG9t0L6WmlzRIw8Nd51erparwPW-37An",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62250882",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "26/10/2023",
      "unit": "SEEDUC/SUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj263HH6khUv6lx2XBuYIXo5k9_UQhvWyjwKsZ6sYcG9cNxW2lyql7Hs8GOPBtJVM9CPbMvw71eOt8Zwi0t9KYbv",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62259236",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "26/10/2023",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3GvQ7OuxZkBb_JTQOd3ea4bdteQpPxrbliBDnFXOWQVIFsnxBaKTNtkz2zZ7lzucWUY4UbDG5NeWJSKtvp3V23",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62300587",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/10/2023",
      "unit": "SEEDUC/ASSCONT",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1jtuprTLfWb3x7w7pbc1GSPlWpqqUNMbuEOoWB6BAQgRteV4qy2a8eDJKLPiUOcqH1k_D7RFdnopNvHg5q_0zl",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62346616",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/10/2023",
      "unit": "SEEDUC/SUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3nRth8xqYKrYtekTrtwUQpNk4kCDpEEZVBlY2MOg_dv5N2aOfzsg7-or44hgpFKiJJbz7zx7p8nNCQDzMfDqIA",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62648992",
      "type": "Lista",
      "date": "01/11/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj31WTS8w2KXeEMODPKedOMwH9bx0QByRRRpFH7zZO-Fq_M5VxKW93aWXHrGruR8T1qj7fFXxBKAoSxba5J6OtBr",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62647778",
      "type": "Lista",
      "date": "01/11/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3ZkOO8bUYEkUWduSzYJTghq_BIo3FMpfm0KqU8s5YfhtBjmk9vdPdIremtp8HsOzJEhCSg-qqsE18XUw6tCXaD",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62657902",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "07/11/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1SceEODjKgsnKj7IkWGrrZ4fm0Pl58BvCsMqwHrOyb4v3AFhV_3qdGEFfBqHjMr3ntVfIR0wr8Wd5O25jlcfxH",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62701702",
      "type": "Lista",
      "date": "01/11/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3OS_ChueCRIjOhLfnoa2DYfykU7voR-seerBtj2QCh1AEhNdQVLTfqhxZSbyxcFZAjoARfCMPLUZ7pgE8qRfNd",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62702492",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "01/11/2023",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2p707oV2U_nOQIL6NN3666TgSGO1he3y-MROvukdQy1q7c8qZmKPsqKQlzkvqzNGGkETzzeCdN2JqPX5YLvtgd",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "62955241",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "08/11/2023",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2PyhwNBxvCetq_gTS2k8qRqNkXAFg11bL4YzCd6IH8nfRZohAP8nOjDXHWT8-32DfwHdwuyz5Vm39mwq8JXDJR",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "63601123",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "21/11/2023",
      "unit": "SEEDUC/ASSCONT",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1zRBV2zLuiNcs_R3WEUttc83p4TVOxpM0tEhXufcuFkuEI9y3LkJLd7i0daYdAt0EFlz6mBPkl-hThRNEMkhL2",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "63925547",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "24/11/2023",
      "unit": "SEEDUC/SUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj39uZdpNt_H0V9p6IBxEkp_u6a2Y7op5NGDnPAYoqRJ8M_bmMf8J2gN6_For9EbvNvXBhZ77wXH3a0OHb0tHXli",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "63925395",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "24/11/2023",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1VDW70XEmNwtoGhOCkBG8P8RLk-mHO7pvNV_5QGSfJg68zpKVU-2jchx1QYHiarN7sCLB-TlLKOHPtyPk_24bk",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "64181773",
      "type": "Documento",
      "date": "29/11/2023",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0kVlerFsc_dZu9ZPTtCicctrwu5ZK35mRRwUpqJjfmtBrftN-D0xehYLZt1gA9gAZmxBEhH2BAJMUhx3bIcaMV",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "64186283",
      "type": "Of�cio - NA 758",
      "date": "29/11/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1PZuIX1N-PcsQJPZurECe7A302zDs6OVv-htLRLIcQA6g7OVZsnx5LDYXXpYufqABh2ix8utONwb4zLYq_QwPd",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "64238939",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "29/11/2023",
      "unit": "SECC/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1MFK0ZVqzatr_bNe_NSNhDay0mr4j2TkwoNVS6MwYFchG2lypij1Nd9UvuXor9fdXQkulsUAgt2disPVuwrKcv",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "64763353",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "07/12/2023",
      "unit": "SECC/SUPDP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3A6AtQaVkoqENJgv2CXpdfXgSFSfCoqGBcrAMNLDZmawtHW6wK2Y2X120x9RLusuunQd6RZ9VZcQzMWAkcy57J",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "64828049",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "07/12/2023",
      "unit": "SECC/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0c-76oWG9GH3SJHpDJdOOf3gD-F6bdOzhd9vw1fwyNyH5mdcevJqIEp-R6bOEteOF1v6BmrawF7P9BTdMth29e",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "65103378",
      "type": "Proposta de Minuta FAEP-FAETEC",
      "date": "12/12/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3CQNZafDyRRVAmDvubicaJcC6iTqD8u2oMOaQQBWnpqUKib5vgfmTZHRfeeiMuRh7XRHDFBYuMfChQPDkU_6Le",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "65107913",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "12/12/2023",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj18sEVWhdfeGQKaeHXeBrGdcA7bBKmg6jSlC0447chs2A-wBgAz-wMyDiwrdWLY3HqWVeENixGSBzBUiV-FYp5Y",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "66931785",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "17/01/2024",
      "unit": "SEEDUC/ASSJUR",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0-tndWikGiDic6bYpi6dVaoXNpQSnWIN37An5ZxwfiAt6gjrg0MCtwKDOUV4QDGIR1cD0uMHmQblzFZLSzrV3H",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "67155131",
      "type": "Of�cio - NA 51",
      "date": "18/01/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3pcBENLhwRItW1pnHOe0AnqFWBPpOcX_05TZbhUKRDkpr0fd6d0H_fyhO1ucGfnqBzFPvlvnJt161kuiux6ebW",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "67560949",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "25/01/2024",
      "unit": "SECC/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2oED9-hQ-qjNBZU6qYjiKS9Tbi7-mYgzAHNVlOgyqHzM1VI9Ryk5TsIR-kep4FpggrxzDsHVcyJKFu0s6zh6mr",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "67575369",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "26/01/2024",
      "unit": "SECC/SUBTEX",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3LquIyF2L75EsVfdi73mXgaQ7mWGa-GBIP4tVYzH40ahhRMgVMmzfKWUo4RN0AsdzRtjLpsQcr2N89rRs80wed",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "67585890",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "26/01/2024",
      "unit": "SECTI/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0m023SGOEWDSJR_huS-Hyyxc9CRHqReZKV5MOuh7aLGCyPd1natT1-GUJj12XKUB9dwIbM9_fVPrLVP7St5fxp",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "68132219",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "20/02/2024",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2M7OsUmPcgs4lCcnEF8AT6kD0vfR9mH5MacGze4jX4RpqunksSus4kI_ipkKSNMYiEFz9p1GZUByd_7b93N9vs",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "70498612",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "18/03/2024",
      "unit": "FAETEC/ASSJUR",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3Or81Iu1CQMe894qfPvHXARbzubwOn39sI7TXdmNRXkfhBtB4xlOTRL1dJH20yu3bhD0ukcbWNKH0jIXhRrXxK",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "70568057",
      "type": "Of�cio - NA 308",
      "date": "19/03/2024",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2QY9cXkxB8ziTEKWvNAa4J5Hz386ukByAsXGlZMaFqlsU1PNDcfPN68CZ2VQa2tUx5eBAGs4685nQJkAmAvdbR",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "72429563",
      "type": "Of�cio - NA 283",
      "date": "17/04/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1Fl7SUZsQhXsjrQKSOepjjWOFO1LHBNo93GKtw-hQdsgrXYVbHU5n1-TSjkiw0Ud-EgdqzFeFnCUFpgELcbi1i",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "72552412",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "18/04/2024",
      "unit": "SEFAZ/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0VKH_N_hpDwQi6iDV9Mw9Ql6K-Aq-FeacHdDIA9PSfiYYElLN63G9o-BtGOnZtSZOmr8I5uR12wfusEyi0hIO_",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "72795939",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "24/04/2024",
      "unit": "SEFAZ/COMISARRF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3Q8JzbmWmcjcdvl6EUvXczBslQxH_ho2Muq98fjlLBj_FSn6KZBRqj5SWnJcrjhBFSkK2nLRoFjmLlOZXkNBtU",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "72801468",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "24/04/2024",
      "unit": "SEFAZ/SUBAPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3uW8GaaeF0SOABYzKCLqJYU68te4oY_jaVBWECfBKyIGiZ_WUdGgzXdEEIUhOyeo-TvQl3YlmG1Tmli9_8bb2k",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "72889633",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "25/04/2024",
      "unit": "SEFAZ/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1n8wyG9fJpIv68MgXUjyJs10MM6x3z1hYST_p4ksEBx82eZ6pARmjbPkIKhEvDGUJc0ywAeGYCGREoae7uDjJ1",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "72946282",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "26/04/2024",
      "unit": "FAETEC/ASSJUR",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3JrYLFZwCOjIMy1xQhRFUug26hG8zfMmrsEbVtoOIDGz94Z0ybFWAIKh1CtRRuIxzEqd6MUbOnMegypzctOlqy",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "74036043",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "16/05/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0mXRlPTtWd71lBJY_2luUoToDtrS4V7C78HeW7dfkbo0Q-_1tEcYpwgMkULS1ATmfbtz8D1IXV-0k5ho12v0LF",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "74791693",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "16/05/2024",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2gV0YTj7b0Diebo71jI_bXLuPbWITTMzCQf3x5lu8zaim5jjfBPTxVbG0YoRrOdNUZ_00kTj-1HvNLM9Dui-Ua",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75285781",
      "type": "Nota T�cnica",
      "date": "27/05/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj35U0KwWbzj5xUtjSgXdmY0GAtxGbpU_875s0zRDJgHXxHcl5aBaqnt1t4ST1AECL4COoeJR3GWrjWX2pou_3Ug",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75505218",
      "type": "Parecer ASJUR/SEEDUC n� 11/2020 -DT",
      "date": "27/05/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0gJf87DGMy_nVdjshjiQJVSQ00I5inj0DveHx0xyI4nRp0oRBux18x7iYiiKdXjyWXLQzN3aGSbNYfaXWGpaFI",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75506997",
      "type": "Parecer ASSJUR/SEPLAG n� 01/2017 - CFTF",
      "date": "27/05/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3WXQWy1S2Qy9BV78aaeEh-vvHUVuMZs9ne7qQ8uAuGoWriSI63-tzBK2LZGwdy1kB3r0i4Q0fq2yycvAmd7PUN",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75508929",
      "type": "Parecer ASJUR/SEEDUC n� 04/2018 - LTPF",
      "date": "27/05/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2dc42vputFBprWb4OXwVi7Ipa6zpwzYpMF_szYVuNyh3-rbJVCCI6I8DiFuGA1s5zysboLQL18TxqeO-LYzaeD",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75510223",
      "type": "Promo��o PGE/PG02/ASS/RRF N� 66/2022 - FDL",
      "date": "27/05/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3nKn6oKmgTR6gepYF2p5Gb2skI90jbfHkQGsH1uXhOicRAWmqXpocvQMevRCgt1j2Xs5H393Yd81M8JrWfBfW8",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75515357",
      "type": "Promo��o SEEDUC/ASJUR N� 576/2020",
      "date": "27/05/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj10fhCKR0CvJbyO61T0hfgv8jnyv_RV8ti4lzTOwthyI51fhYINaVCpx8F3pL3tJpkGN0CpIyK-B2i6WSYXUt8Z",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75542512",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "28/05/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1ksUX5TEqUCBWd7-pYP7qknu3pucQKpBqFeiGFMO0qp3Oixb6uUGuvHUlOT6I9r4638xyqfau6h6kKcrrkA0Am",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75621111",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "28/05/2024",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0p_Eb-HiMHLxHh8vwKIzDgcFp9rXwKr1eDfu_Z6HYQ9UEB-mlZ54YdWb_Zrw9zr2z5QnrzumnfgEsrQkLXEAL5",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75775781",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "29/05/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2abghV-arklQSXjS_uanF9AHu3QJNMIHzZFlcgoJj7kYScdycjMStIG_6ENoQRjPuqmC8O7F8bMkrDS8vy3_oF",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "75880267",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "04/06/2024",
      "unit": "SEEDUC/ASSJUR",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2jqO5Mfkn99Ws-YYUpf5vonJ_ZsMtz2UUKTHXRS11qQm-fUQqUTpeKAnEZwUo1GhD5BmgnCryCnj0dCw5QLR6G",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "76084895",
      "type": "Of�cio - NA 435",
      "date": "13/06/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0xaSt7euYAWCAKJYzwGQJMCdfQUVrNV-IcxQTWwyo9Y49TQ0QHctHjVkPGPZ19YcynBK_eTIYzAZoE8OUJa-rL",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "76086920",
      "type": "Of�cio - NA 436",
      "date": "13/06/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3GclRHMFuIgII4Q3HJYRaXZA4v0f2PtpVmaXWzd190LYSgVXRfihcg8QdIzrFAWIB4jRCVxD6niNoixvDRXEnt",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "76982130",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "18/06/2024",
      "unit": "SECC/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0Iv57NR-Y7YMfMOxt_zIL8FyLVBEQ9y5cICE__jggMno8FCdIed62jLO6U5YL2UBdmabu9jJ0seFnNGMp7D_Wr",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "77251099",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "21/06/2024",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1TKgfwNO0vMi1RU8Dq63cbuBnizsdV99M33mNZxiD5sFWVUPcyzM59kmsw_SGyxH-e7IzJLkLCN7qrC_m1N_my",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "77320782",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "21/06/2024",
      "unit": "FAETEC/DIVRH",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2yrQ1jm5wz2IiIowwlv-nAKaMpbEY3un8hhXJlwiAQjwXTUrbNvTCBAipZ8HX18f_UT-H0oJCP6C1mO9_whMhw",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "77738330",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/06/2024",
      "unit": "SECC/SUPTEX",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj06vPoTxxjk_M_Zc3ufXS9ufhosVeuEvDOsZroC7dWiG3qT9NAAiKztXv36r0Q-fCBfuh8WxkFrwlIG3VChp1rC",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "78044417",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "02/07/2024",
      "unit": "SECC/COPRE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3TfVw5Uv8CJhf8vz-SsUeoxbos5Lgm8yj7JoDycxhffoVBVMHHzzeHFrkxmm3XLBNcllmMH0t8Wyh3yIsC7_es",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "78092872",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "03/07/2024",
      "unit": "SECC/SUBGEP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0hhgEZmAKYPryXVzjQliRPGi8jdKA7oHF8qd5cFXCXbHiGEtg_zbX-yLtUpCHIAxguANF31JKtqPVcmHngbs5w",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "78601170",
      "type": "Of�cio - NA 765",
      "date": "10/07/2024",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3cp-LqFvwGqFtc5q9_IQgo_CZFJ59CR-LxGK4T1KDWI9daVORgkFlK0v6uJNdTJAuJ1JiwYKraG6wRek9s3ZK4",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "78788722",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "12/07/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3FJyvLafDESUB56DpfhWlFEkQtOZXPrumVxV5EjflEo5sPXTOhtCUPCnPtuFjm6wRqFbnAP3LPwGH9YdZUsP8W",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "78809700",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "12/07/2024",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0Fyar5HXENL7V01MwJKydOMCcZzsqBgrec-lWrcRo_Jqz9KL3zsPGBWzlL_A_coySVB_uc1qH3rgxIB7tAAxG3",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "79750951",
      "type": "Planilha",
      "date": "26/07/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "79751913",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "29/07/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj21zteB9yIPCae7Zj3Wubpqu3QLzV6-Y6FkrqO7Cahp64nR0Q_zmpujg6giD2sKxMwmpqMerYSuz59U4AbKsUls",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "79949613",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "30/07/2024",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0A8-Dou_rYYy2noJ5XnXIZwqrHAD3TasRAc2n77c2mOYgSCvKzeL_vLMwCpzwBO7FzPrli0isq-e-f4XgxKwpm",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "80135969",
      "type": "Of�cio - NA 550",
      "date": "12/08/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3pYJ3CIb2u1o_b5OZT_k7jqjyu-ynNj3QZiUXfwaLhaXRz44zXWzjlCsxh8pxfOaJPSOFLMBYF_cG9esvHOPtp",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "81011123",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "14/08/2024",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj33ON18d3BmfJ6OfeeFY4L6BPPduXKcQLxnN32JrLz0JdYbxaX--bOH1_pr5pTb4hYiB_r6S8niStHc0mNk4ABq",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "81256125",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "22/08/2024",
      "unit": "FAETEC/DIVRH",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2s93e67UMMioqH6VTbH3fsDLfUc8JdpUbQAOB0Cv3D0leAQ_wU_xNbNAKKwfMBdQRBf0_khXeqsEWvQUtZ1s50",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "81919026",
      "type": "Of�cio - NA 936",
      "date": "03/09/2024",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj2jbn1jOJbUEu4o_tEkiZKBp_Dk6furnPaMn82lg3xO7gEe3ranwZRVdYUP_U7_zJH36TUNJmMFzL4dOJy5CsfD",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "82473088",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "04/09/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0JY09Sw1fmpUcKgcuq6j8CTeKY7a4RL5EWiR4pzSGi0Zfva2qcDJmGvUaxIFTZ9ovssfNTRnYnpl3EGdyyw65z",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "82498182",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "04/09/2024",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1NpV-Fz629kOxQ_7_XpSadWcmS5pLJqgB4vmUOPwB_HI-4FWYyAMrFEezHMkf14dOSUi6GoNfvb2VYbRfM4OZb",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "84654079",
      "type": "Of�cio 01/2024 - COMISS�O CONCURSADOS FAEP - 1993",
      "date": "03/10/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3Dn1mMj9IiPZUAKvwLfxzV-SsvZknutECa2-bb4C0BwCXT4D_CuKn3aEqWeC9u8vXR1D_ey9OC1ZUUaYnAJDVC",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "85721526",
      "type": "Anexo #77839",
      "date": "18/10/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "85722503",
      "type": "Anexo #77562",
      "date": "18/10/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "85722713",
      "type": "Anexo #77838",
      "date": "18/10/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "85723625",
      "type": "Anexo #77834",
      "date": "18/10/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "85737376",
      "type": "Edital",
      "date": "18/10/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1nI1hXzKthjhKXDAQ5lAD-MKuYHqbUoqUjpzr4BYx8umPjR664A7k8zpLQanWlaUbSGYSAQWDRjbUCpbkgYu0G",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "85738598",
      "type": "Planilha",
      "date": "18/10/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "85743760",
      "type": "Anexo #77564",
      "date": "18/10/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "85764212",
      "type": "Anexo #77435",
      "date": "18/10/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "85765770",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "18/10/2024",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj0oagLuMK20JQsKz6XNDvcKipiP0CVgu5-1_7ri0sJdIk3w_1wT0_VTyXqGyZ6lmg3z6nqZz2QPhzjlITe5n4Y5",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "85885206",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "21/10/2024",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj3J_zqWopMYluyGkaRfNSYmu_rHgJ9-Yo-HewBBbpkHU4UjNOpDbC2evvM5xCouZiZKsnXrizXe5H7mTO9n6qOB",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "85914477",
      "type": "Of�cio - NA 815",
      "date": "22/10/2024",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1B9B6qxCp1hF47fKSwFEQHnCD04hnmWhWCoilwpieNMDAm7hr3PbtvQY8ccF9jmhyzqk1SvtLlF7pfJwcjRj2n",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "86028175",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "23/10/2024",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?d-qBlq_KF4_2fdKMgucKGw2SOOsdRDgKOTtYkpTOQj1p1wzz8iVNKrlm5tsw52RWbglsJJx5CG82FFOFNxa_NgGZgYnEtoOhs7JVTPbRw0a5jP6VCM5VkfSepywDjkJ0",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "124620003",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "05/02/2026",
      "unit": "FAETEC/DIVRH",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNv2icp18o0ToCBixJHE0Gny5dzf32YOxdU_k2q05AoEC8pKeafNTzPWw4YOvkjkOaALQKN6U0AI1B-9xlX6JFO",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "124716073",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "06/02/2026",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNM4qARaHsLl0N4vxf_zttcU4GApITKU4P5cR7Zfo_Wy1Cm11P2J9F6q-Wt89ZF4HcYclwjRDL_O9eyygeMZQuIV",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "124750176",
      "type": "Of�cio - NA 65",
      "date": "12/02/2026",
      "unit": "SECTI/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNjqH8IZQcOM27xcen6xfzRRf1R9Slt8v_bQr6Mom9fNYSyyLXAaiUJUw6NwJu9eFUc-p9IO59Jwlp3CJsp-EXc",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "124942312",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "10/02/2026",
      "unit": "SECC/SUBGEP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNMiecQOYc2ZZ-cqJBhgcE5CIiPnCNbbTfRGqgmpP9ya7dsIIkfIYGPLSbH9LTlVCcY0Hy-zK48B9k3YiKfynvzo",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "125969871",
      "type": "Despacho de Encaminhamento de Processo - ASSJUR",
      "date": "16/03/2026",
      "unit": "SECC/SUBJUR",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOzmTn2vqJvK5C3AMG2jDmoDELKJC7drZcSnYrhejAPnOQW6E4C9ORJ4WzbuGA4UpCZ5Qv2rAWhYicmbhK5XY6W",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "127279018",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "17/03/2026",
      "unit": "SECC/SUBGEP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNrkFoPZ85tXJcgHzp_HcQgEG5HJZ0BD7JGHtlUY9jVdTITtmMk8-RKKQdctNXPO08oDmiLxoFZfoNRMMX41Sx2",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "127292348",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "17/03/2026",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOY2_q4dh2gILekMQbwhX3Kn3ul6I6mCSkNUBHN4zw7KVSdLOC1HDZ2CroAn9PAkgLXrXMI7IRVpLU1FsFOSMTw",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "127309890",
      "type": "Despacho de Encaminhamento de Processo - ASSJUR",
      "date": "17/03/2026",
      "unit": "SECTI/ASSJUR",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOGGE5Xcvm-l_Zz-X-GO_Oqrx3CsxBRycl9ULYrc_hQV75crTMttYBbAuTMnQe0i9sf6ayPSm_umV8b9JH523Tt",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "127336810",
      "type": "Of�cio - NA 203",
      "date": "17/03/2026",
      "unit": "SECTI/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNM4mAifY9NS00jqWbiR4_qXQw5-kD0VeIWAiCCdEri5j4zEMQUyAvrj0X3_nKPG8oREgbbEUc3c6wP8OlNPyAoV",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "129081006",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "06/04/2026",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPA7VJVagUmSKZl1eCYNzsy_N6RG73CxsNFIHxaCWmg5icYWcQtZDGyNMxxv56V4c44iqErNaVP5eAKboo8GM_Q",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "129200280",
      "type": "Despacho de Encaminhamento de Processo - ASSJUR",
      "date": "07/04/2026",
      "unit": "FAETEC/ASSJUR",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "129391540",
      "type": "Of�cio - NA 261",
      "date": "09/04/2026",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNP6QzDIsaLUhb2gD1-fCPsANOJJBYI6A31uGhfI0sNWMyOu_rDyb23oqr7jOpz5shn1wYHwqADZTIvPF900hOW3",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "129425383",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "09/04/2026",
      "unit": "SECTI/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNP0-JI1JTiSoXjCnb5iYZkmzls7O04o9l-np69XxQMgnlG70k0gyocWiKOzH70mvR0iAMicN-yy8YEThbmz57KG",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "129662008",
      "type": "Despacho de Encaminhamento de Processo - ASSJUR",
      "date": "14/04/2026",
      "unit": "SECTI/ASSJUR",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNMpsTJnlxRQZZQlxNrbRQU4dAT-FuGDHkiXRjX_hmxPwePo7yLW7_213n3IPJrkRJJABZgSvJfWMbEJjxHb7LXa",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "129885449",
      "type": "Of�cio - NA 274",
      "date": "15/04/2026",
      "unit": "SECTI/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNP0NL4bnz_SgZctrp3cvLNpv8wV5_TKV3coS6EHQA2v7tEaIfdA8JGlOh62Pop-0-tmZ2FtzAQV4roTN2tpaMzk",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130459605",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/04/2026",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNMhtBJR2ECbTVicR9aEaHqOIXYVkDYQkpNGKetDGd5GeoI3_H2mChnRi6D1BgfXLJKiTwe_UB3GlwH-rAheVYrk",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130473939",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOvxrG5wZScFQXwhpNDwFtNQ3-ZQftPXOnDEs3Ou2Wu6JpCtg9q-EAR3s_EZqGmhkNpA6K9h7pqJlFeM6Iow-B0",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130511325",
      "type": "Anexo",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNzrQFRm79LgpEjBD1AngsbQb9HHXGjB7ZK-YoJI1h_aWgcrai8RKTQmogSvMkGqvkNGVo8C4p3YId7lTwzkDcz",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130512651",
      "type": "Anexo",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNN4Mcja-GBGgQgtHkXI3KEjCkvhF-wMAHlnw2d424ROnNPkURroXaLfxj_7Y0MvjO7yqZQoiR2KTn-wZ_s2Ss8x",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130515831",
      "type": "Anexo",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNvDqr32ptz5g1AdEmm80TmXVOc9FXQsUSvkQ408mMLP2xb5d_UuE_NPeqoC3t-Kn9nLI3JrdINZ-XPDQ7LS34Q",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130517077",
      "type": "Anexo",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNM-RNQtBxK8cp9wVa8miKwTL0uE48eVzLG5ppNpZFSrkKgy8OYu7apDf1oOwGUZZo0vtStdMYXKrrZ7qm1k9WEm",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130517795",
      "type": "Anexo Lei Ordin�ria 2735/1997,",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOohLqqSvRBFsYmaL1LN0BSQssFUZAMpizG3JhVOhLMLztpBLl3Yp2AFoapr5ps-ZNAoZRPdMCSG1Z_k4FUQTBT",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130519533",
      "type": "Anexo",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNN_wafKhYamoEANfKeSBdQ9uC-iJ9CM1Fah1FxtrTfzJLpVwyYbw-yrE6JipXZff8b9dB_dmIaTXANpkSHRKPCx",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130521981",
      "type": "Anexo Lei Ordin�ria 5766 de 29 de junho de 2010",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNf-2LSROYbyNKXipVSYrCvonydHqIZnr6_NnWIDPmQfIEJf_GEqqODrVxpLOQfW5kMzTUgLL7HjdUydQ-BL833",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130521305",
      "type": "Nota T�cnica SUPGP - 2022",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNP5RkC5uCSh6tJIRzAm-esVrAQkfdc4yC4HDuRngwjwKCa89Ymu8ReVbNS5Fzt3_rRzBqYs9hw4tOX283RDuf0X",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130525447",
      "type": "Anexo",
      "date": "27/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNA9RHxEklCTsZHOVrxenowiUmcYyUNXYdxvALHlR96IyCfiNwbWPzcqqJX1XqZ2pkBM-VlM6fWT_tsnzNNQTYo",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130528267",
      "type": "Nota T�cnica",
      "date": "29/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNO04mfEdnNCJ2wQZfr7D5peXbc5_1OBdfFvlZcMZaK06aA70x1x9L1UkU9pEaVJw-BaMkdJlM08tuouD6NY9RrA",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130562126",
      "type": "Minuta de Projeto de Lei",
      "date": "29/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNMcfREqSEJyXGM6Rq9l7zgT527kmxabJTw55Qv4JSkU17CJO3Dv0slXJUCI4rtnBgZWi3eFyRvbhqJMGe6c2AxH",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130574847",
      "type": "Justificativa",
      "date": "29/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPR07t29a7YI-aVJxR22la1htHIzKnnAypFLZUpTxNhBqK1fjKF2LyPTTCfaV_W0VBYi9VhYd0OanmyHOZrlWju",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130579185",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "29/04/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOnFEJmWXg0MuCBuJaHzLTNKrOcmUKcb43IWdZeZ5EnCUjS95CAlNsWcMM2alVbHHFnq3rjOn5fOB0ms0VOpl7s",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130741489",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "29/04/2026",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOdpqwtO7b5XrNRiFdE1f3venk3q42RS3MKu6rvOdQX7qUdFFc1ENyr6vcWFcjlCQ1fmQgS52sxYBzvP7nM7X1z",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "130851851",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "04/05/2026",
      "unit": "SEEDUC/NUCSPEA",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "131125941",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "05/05/2026",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPjmCiuh7YsWSl0EGfu86lwKcM9w93YaPyMX9kb5E_0fWN-MhoHCbXQf0kou--6PqNdUYjmUgJQljcNst6NODHo",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "131136402",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "05/05/2026",
      "unit": "SEEDUC/SUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNONaEHXt9FnmwG4J5XZSd1havEMFLTHaOIhepH8lpIE__EkxtXqq0tMlQGi3_STf3YGN3V9ZmSI5C96tGa5adgR",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "131169774",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "06/05/2026",
      "unit": "SEEDUC/ASSUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPa5XWNiKETQlRS-ZNqevKCVh5QIgFc3WN3Uqvy3fZIbZWCknmjdfKXwdIH7QLGwPUJiGGkW17--N7VGDBvJxKH",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "131721687",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "12/05/2026",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPPRZOlWkVrBPhiLCopqpXqkXGjQse0WR82xnY0wUc62MOr8Ofe1g6_X6u5GzCeYRQdiXXMLxV-XfsjDzqzQVsL",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "131868597",
      "type": "Impacto",
      "date": "14/05/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": null,
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento foi criado, mas seu conteúdo ainda não está liberado para leitura pública."
    },
    {
      "number": "131869119",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "14/05/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNMrG5aDjD6swF6NbZc60SISqQIxRM7e6xR0UoiT5IBB__ZkWG3ErbZojQwdryqBjcwpp-xA9SbZfwMijr5l7owY",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "131898795",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "14/05/2026",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNTDGcuV3VDogwlHaCbt8DsLLSI6AjLkTvups4VhNU9d_2n0oQFaoHOZTBtJOt91bu_96pqZAnR8fc79-Wur5Ai",
      "excerpt": "",
      "excerptVersion": 1,
      "simpleExplanation": "O documento já possui link público, mas o painel ainda não conseguiu extrair seu texto."
    },
    {
      "number": "131960504",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "20/05/2026",
      "unit": "SEEDUC/ASSUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOiOWO0LbXwxF-cQyuLXfEoozgK1v7oTUfOOXws16MZNeWVloQ5gvLtTO5eBinpAkMWPSbqiVePiBXe_xjUG0iW",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria ExecutivaÀ Subsecretaria Executiva - SUBEXE, com vistas à Subsecretaria Administrativa- SUBAD, Em atenção ao solicitado (131898795), verificamos não haver na planilha de impacto orçamentário (131868597) menção a eventuais custos com efeitos retroativos da medida em comento, conforme Nota Técnica SUPGP nº 2026-02 (130528267).Ante o exposto, encaminhamos o p.p. para ciência e sugerimos o envio dos autos à SEEDUC/SUBAD para manifestação e eventuais ajustes na planilha de impacto, caso necessário. Gilvania Amaral Superintendente de Orçamento e FinançasID 5108551-8Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "Documento produzido por SEEDUC/ASSUPOF. A leitura deve ser combinada com o movimento seguinte do SEI."
    },
    {
      "number": "132342592",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "20/05/2026",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPlK01YVW2WUERqwMoftl5Io9-tsPzwyBMCNqrLGLCw64uQ2PULdcMa3wVU0oVue6qeLXLEsyweJa59U5fd-WsA",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria Executiva À SUBAD,Em prosseguimento, considerando o Despacho ASSUPOF n° 131960504. JOSÉ MAURO BRAZAssessor/SUBEXEID.: 5114243-0 Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "O documento tem linguagem de continuidade. É positivo para tramitação, mas não equivale à aprovação final."
    },
    {
      "number": "132345223",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "20/05/2026",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOK4by1FNinAZZ7EGbS65jQQQhGeM_xXOnDmtC2Pb1TjSdwAzsmXF6RmIKpRLD5mVlE1nJXhdz_0XyiJLlqbkP-",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria Administrativa À Superintendência de Gestão de Pessoas (SEEDUC/SUPGP),Trata o presente processo sobre a regularização da situação jurídico-funcional dos servidores de apoio técnico-administrativo, oriundos do concurso público realizado pela Fundação de Apoio à Escola Pública – FAEP, no ano de 1993. Encaminhamos o presente expediente à essa Superintendência de Gestão de Pessoas para ciência, análise e manifestação, com vistas ao atendimento ao requerido pela Assessoria de Orçamento e Finanças (SEEDUC/ASSUPOF) através do documento 131960504, encaminhado pela Subsecretaria Executiva (SEEDUC/SUBEXE) por meio do documento 132342592. Diego Bazani BoechatID Funcional nº 5013596-1Analista Executivo/SUBAD Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "Documento produzido por SEEDUC/SUBAD. A leitura deve ser combinada com o movimento seguinte do SEI."
    },
    {
      "number": "132398524",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "20/05/2026",
      "unit": "SEEDUC/SUPGP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPiJBewuvqnpoohYRviPK2SrbjwoIwonrJIe3GWaMSF3iMuCQMTaeX3DXyqdsc0UiRNMkFJpAOAi67u2fr71O9o",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria Administrativa À Subsecretaria Administrativa (SEEDUC/SUBAD), com vistas à Assessoria de Orçamento e Finanças (SEEDUC/ASSUPOF), Em atenção ao índice 131960504, da Assessoria de Orçamento e Finanças, informamos que a minuta de Projeto de Lei anexada a este processo, sob o índice 130562126, não contempla, até o momento, efeitos retroativos, s.m.j., questão que será decidida em outros âmbitos. Assim, encaminhamos o presente administrativo com o Impacto Orçamentário Estimado (131868597), referente à conversão dos servidores ativos desta classe para os vencimentos indicados no Despacho de Encaminhamento de Processo (61568455), levando em conta as rubricas básicas para os cálculos. Monica da Cunha LongobardiSuperintendente de Gestão de Pessoas/ SUPGPID Funcional: 41322657 Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "Documento produzido por SEEDUC/SUPGP. A leitura deve ser combinada com o movimento seguinte do SEI."
    },
    {
      "number": "132405506",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "20/05/2026",
      "unit": "SEEDUC/SUBAD",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNP4PixVXbIVAjn9XOPL3teNF3bkAqfk6H3A-YkPEw9CzzWJ5NR_iwbMwUUUKabDl70CSToy_8_uP-sbtYOIWH-X",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria Administrativa À Subsecretaria Executiva (SEEDUC/SUBEXE),Trata o presente processo sobre a regularização da situação jurídico funcional dos servidores de apoio técnico administrativo, oriundos do concurso público realizado pela Fundação de Apoio à Escola Pública – FAEP, no ano de 1993.Em atendimento à solicitação realizada pela Assessoria de Orçamento e Finanças (SEEDUC/ASSUPOF) através do documento 131960504, encaminhado por essa i. Subsecretaria Executiva (SEEDUC/SUBEXE) por meio do documento 132342592, restituímos o presente expediente com as informações e apontamentos realizados pela Superintendência de Gestão de Pessoas (SEEDUC/SUPGP) através do documento 132398524, com vistas ao prosseguimento do feito. Luciana Gomes Magalhães Subsecretária de Gestão AdministrativaID: 3484144-0 Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "O documento tem linguagem de continuidade. É positivo para tramitação, mas não equivale à aprovação final."
    },
    {
      "number": "132460300",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "21/05/2026",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPbeqHyzqCsmV2KRIGYbE8_0wnOr_dt29g8qeIQlHpvmVsigc1uStQAZce5g_N22MRHLDMeZa_qZs4ITaANAzkH",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria Executiva À ASSUPOF,Em prosseguimento, após novos pronunciamentos da SUBAD e SUPGP (132405506, 132398524). José Mauro BrazAssessor/SUBEXEID.: 5114243-0 Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "O documento tem linguagem de continuidade. É positivo para tramitação, mas não equivale à aprovação final."
    },
    {
      "number": "133577189",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "09/06/2026",
      "unit": "FAETEC/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNAvtTYph-qnGPOa2kNKneDGoNGmTjFR_vy6RjGPBC0dBjnIXZT8Mx39973f2Pp-cZepIKEeWl687jiCS5w9FRD",
      "excerpt": "Governo do Estado do Rio de JaneiroFundação de Apoio à Escola TécnicaPresidência À Presidência - PRESI, Após visto e analisado o presente processo, que trata de proposta de edição de ato normativo voltado à promoção da migração de servidores da extinta Fundação de Apoio à Escola Pública – FAEP para a estrutura da Fundação de Apoio à Escola Técnica do Estado do Rio de Janeiro – FAETEC, registro a manifestação da Assessoria Jurídica da Secretaria de Estado de Ciência, Tecnologia e Inovação – SECTI, constante do Despacho de Encaminhamento de Processo (indexador nº 129662008).Considerando a relevância institucional da matéria e os potenciais reflexos administrativos, funcionais e orçamentários decorrentes da eventual adoção da medida proposta, submeto os autos à apreciação da Presidência desta Fundação, para ciência e deliberação quanto ao prosseguimento da instrução processual e às providências que entender pertinentes.Ressalto que o presente encaminhamento possui caráter meramente processual e de assessoramento, não importando em manifestação de mérito acerca da viabilidade jurídica, administrativa ou financeira da proposta, cuja análise compete às unidades técnicas e jurídicas competentes. À consideração superior. Wagner Luiz Coelho de JesusChefe de Gabinete - FAETECID 5072427-4Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "O documento tem linguagem de continuidade. É positivo para tramitação, mas não equivale à aprovação final."
    },
    {
      "number": "133607874",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "09/06/2026",
      "unit": "SEEDUC/ASSUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOYHXn5cgGUNtot9WhXStbheiYR-I200UZQtYkBx1j87AGKek5wZDuc_Joq5hEvem4NIVCTzmWs3W3zmOGhz5fC",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria Executiva À Subsecretaria Executiva - SUBEXE, Em atenção ao solicitado (132460300), informamos que, no momento, não há disponibilidade orçamentária para atendimento da presente demanda, em razão da despesa atualmente autorizada para a SEEDUC e do impacto financeiro decorrente da medida, conforme demonstrado na planilha de impacto da SEEDUC/SUPGP (131868597).Ressaltamos que o pleito é considerado relevante por esta Secretaria, motivo pelo qual estão sendo realizadas consultas e tratativas junto aos órgãos centrais de governo, planejamento e finanças, com vistas à análise de sua viabilidade e à identificação da melhor forma de atendimento.Por se tratar de tema prioritário e de interesse desta Pasta, o assunto vem sendo acompanhado com a atenção que sua importância requer. Entretanto, a adoção das providências necessárias depende da conclusão das análises em curso e da superação das limitações orçamentárias e financeiras atualmente existentes.Ante o exposto, encaminhamos o presente para ciência e demais providências que couberem. Gilvania Amaral Superintendente de Orçamento e FinançasID 5108551-8Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "O documento aponta problema de disponibilidade orçamentária. Isso é obstáculo financeiro, não necessariamente negativa jurídica do pedido."
    },
    {
      "number": "133800588",
      "type": "Despacho",
      "date": "10/06/2026",
      "unit": "SEEDUC/SUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPTCBXLkBs24FrVnsEZTFB3L7Ascp0giZsbYTWNEqWy5knwQH--KykAzrMqxb9DySctb7FFEQMdJyCVfWZZB8yW",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria ExecutivaDespachoTrata-se de processo administrativo que versa sobre a situação funcional dos servidores cujos cargos efetivos foram transferidos da Fundação de Apoio à Escola Pública do Estado do Rio de Janeiro – FAEP para a Secretaria de Estado de Educação, em decorrência da extinção da referida Fundação.Considerando o pronunciamento da Assessoria da Superintendência de Orçamento e Finanças – ASSUPOF (133495946) acerca da disponibilidade orçamentária, sugere-se a restituição dos autos ao Gabinete, em atenção ao despacho GABSEC nº 131125941, para conhecimento e avaliação quanto a forma do prosseguimento da matéria. José Mauro BrazAssessor/SUBEXEID.: 5114243-0 De acordo. Acolho o encaminhamento sugerido e autorizo o prosseguimento dos autos na forma proposta. Gleice Renata Martins MenezesSubsecretária ExecutivaSecretaria de Estado de EducaçãoID. Funcional nº 4420972-0 Rio de Janeiro, 10 junho de 2026",
      "excerptVersion": 3,
      "simpleExplanation": "O documento tem linguagem de continuidade. É positivo para tramitação, mas não equivale à aprovação final."
    },
    {
      "number": "133904370",
      "type": "Of�cio - NA 623",
      "date": "10/06/2026",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNjFHW_dB2uY8uuN7_0zyV4lI7WHXi2FbrrgsCRDaI01NsI5VUNvk80rqXAkHUKBBp_xglh2CkolNYcTw1awUOo",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoGabinete do SecretárioOf.SEEDUC/GABSEC Nº623 Rio de Janeiro, 10 de junho de 2026Ao Exmo SrRAFAEL ABREUSecretário de Estado de PlanejamentoSecretaria de Planejamento e Gestão Prezado Sr Secretário,Cumprimentando-o cordialmente, sirvo-me do presente para apresentar todas as tratativas e esforços empenhados pelas áreas técnicas da Secretaria de Estado de Educação para atender o pleito da categoria. Contudo, conforme informações prestadas pela Superintendência de Orçamento e Finanças (documento index 133607874), não há disponibilidade orçamentária para atendimento da demanda em decorrência do impacto financeiro decorrente da medida, de acordo com estudo de impacto da Superintendente de Gestão de Pessoas desta Pasta (documento index 131868597).Isto posto, submeto o presente a V.Exa., no intuito de verificar a viabilidade de atendimento.Sendo o que nos cabia informar no momento, permanecemos à disposição para outros esclarecimentos e renovamos nossos votos de elevada estima e consideração.Atenciosamente, LUCIANA MARTINS CALAÇASecretária de Estado de Educação",
      "excerptVersion": 3,
      "simpleExplanation": "O documento aponta problema de disponibilidade orçamentária. Isso é obstáculo financeiro, não necessariamente negativa jurídica do pedido."
    },
    {
      "number": "133959490",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "11/06/2026",
      "unit": "SEPLAG/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOkGQUIyIyqwAjkuxCwJAQTnvUSf8tejilokT3J2IO0kfLSwMiSSMPrrIAIItAbddSa9L_3rOAJIE8B2La8Za81",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoGabinete do Secretário À Subsecretaria de Orçamento - SUBORC, Cumprimentando-os cordialmente, em atenção ao Ofício - NA 623 (133904370), encaminho o presente administrativo, informando que, após análise das tratativas conduzidas pelas áreas técnicas da Secretaria de Estado de Educação (SES), verificou-se a impossibilidade de atendimento ao pleito da categoria. Conforme manifestação da Superintendência de Orçamento e Finanças da SES (133607874), comunicando que não há disponibilidade orçamentária em razão do impacto financeiro da medida, conforme estudo elaborado pela Superintendência de Gestão de Pessoas daquela Pasta (131868597). Assim sendo, considerando a pertinência da matéria, encaminhamos o presente administrativo para apreciação. Atenciosamente, OCTÁVIO VIDAL Assessor do Gabinete da SEPLAGID Funcional n.º 2025678-7 Rio de Janeiro, 11 de junho de 2026.",
      "excerptVersion": 3,
      "simpleExplanation": "O documento aponta problema de disponibilidade orçamentária. Isso é obstáculo financeiro, não necessariamente negativa jurídica do pedido."
    },
    {
      "number": "133972949",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "11/06/2026",
      "unit": "SEPLAG/SUBPLO",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNP2BkLo_6W8R_E02RSClt6x5gGU732foHgmlQ9bOJ2Nm-unMWFZDrS7AjKLs-LQfWZ1y6qR18bybopOKzxoZT5l",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Planejamento e Orçamento À Subsecretaria Adjunta de Orçamento,Considerando o Of.SEEDUC/GABSEC Nº623 (133904370), encaminho o p.p. para conhecimento e as providências cabíveis.Rio de Janeiro, na data da assinatura MARCOS MOREIRAAssessorSubsecretaria de OrçamentoID. Funcional: 1940053-5",
      "excerptVersion": 3,
      "simpleExplanation": "É despacho de encaminhamento: manda o processo para outro setor tomar ciência ou providências. Sozinho, não aprova nem nega."
    },
    {
      "number": "134225890",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "24/06/2026",
      "unit": "SEPLAG/SUPEFIS",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNM4Pz4I4h3MfzgHLBxM_vdUao-qgA2qygzUSYcbQbxg0Pb822rXfPvF12iJtXpvHKDVFK5WonsAePG28FBo46IS",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Orçamento À Subsecretaria Adjunta de Orçamento,Trata o p.p. de proposta de migração dos servidores concursados da extinta Fundação Apoio à Escola Pública - FAEP, atualmente pertencentes ao quadro de pessoal da Secretaria Estadual de Educação - SEEDUC, para o quadro da Fundação de Apoio à Escola Técnica do Estado do Rio de Janeiro - FAETEC. Para isso, através da Resolução SEEDUC nº 6.164 de 27/04/23, foi instituído um grupo de trabalho com o objetivo de elaborar estudo técnico acerca da viabilidade e instrumentalização dessa migração, com membros indicados da SEEDUC, do Sindicato Estadual dos Profissionais de Educação -SEPE, do Sindicato dos Executivos Públicos do Rio de Janeiro - EXEC-RIO, da Secretaria de Estado da Casa Civil - SECC e da Fundação de Apoio à Escola Técnica do Estado do Rio de Janeiro - FAETEC. Posteriormente, a Resolução SEEDUC nº 6.174 de 13/06/2023 altera a Resolução anterior incluindo o Rioprevidência para a composição do grupo de trabalho.O Relatório Parcial realizado pelo grupo de trabalho (57456783) traz uma breve exposição sobre o assunto. A FAEP foi instituída pela Lei Estadual nº 1.176/1987, vinculada à Secretaria de Estado de Educação. Posteriormente, com a publicação do Decreto nº 16.807/1991, a FAEP passa a vincular-se à Secretaria Extraordinária de Programas Especiais - SEPE. Com a promulgação da Lei nº 2.162/1993, foram criados os cargos públicos integrantes do quadro de pessoal da FAEP, a serem providos mediante concurso público de provas e provas e títulos. Em seguida, a reorganização administrativa promovida pelo Decreto nº 21.258/1995 estabeleceu que os servidores oriundos da extinta SEPE permaneceriam apenas provisoriamente à disposição da FAEP, determinando expressamente que, no prazo de 180 dias, a Secretaria de Estado de Educação deveria promover a regularização definitiva de suas situações funcionais, mediante a absorção do contingente pela própria Secretaria ou o retorno às respectivas origens funcionais. Posteriormente, a Lei Estadual nº 2.735 de 1997 alterou a denominação da FAEP para Fundação de Apoio à Escola Técnica do Estado do Rio de Janeiro - FAETEC, aprovou seu quadro permanente de pessoal e redefiniu suas atribuições institucionais. A promulgação da Lei nº 5.766 de 2010 facultou aos servidores à disposição da FAETEC, em 31 de dezembro de 2002, a opção de permanecerem vinculados ao quadro da Secretaria de Estado de Educação ou serem transferiados para a FAETEC. Art. 1º - Ficam transferidos para o quadro de pessoal da Fundação de Apoio à Escola Técnica do Estado do Rio de Janeiro - FAETEC os servidores da Secretaria de Estado de Educação - SEEDUC que, em 31 de dezembro de 2002, se encontravam à disposição da mencionada Fundação, assim como os respectivos cargos. Em função da divergência remuneratória dos servidores ocupantes do mesmo cargo e oriundos do mesmo concurso público, parcela dos servidores que optaram pela permanência na Secretaria de Estado de Educação passou a pleitear, junto ao Chefe do Poder Executivo, a migração para o quadro de pessoal da FAETEC.Em Outubro de 2023, por meio do documento (61568455), a Subsecretaria de Gestão de Pessoas – SUBGEP apresentou a estimativa do impacto financeiro dos servidores ativos e aposentados relativo ao enquadramento dos servidores ex-FAEP vinculados ao quadro da SEEDUC em função da tabela remuneratória da FAETEC, com o impacto financeiro estimado de aproximadamente de R$ 275.000.000,00 (duzentos e setenta e cinco milhões de reais) anual. O Relatório Final do estudo realizado pelo grupo de trabalho (62657902) foi encaminhado à Secretaria de Estado da Casa Civil - SECC juntamente com a Nota Técnica GBE Nº 001/2023, apresentada pelo Rioprevidência, onde ficou esclarecido que os servidores da FAEP que migrarem para a FAETEC continuarão no mesmo cargo e carreira, havendo apenas equiparação salarial com o atual quadro da FAETEC e, que a princípio, não haveria qualquer tipo de transformação de cargo ou ingresso em cargo/carreira diferentes sobre regras de aposentadoria (60584818). Após o retorno da SECC, a Secretaria de Educação acostou o documento (65103378) contendo minuta de Projeto de Lei que propõe a transferência dos servidores da extinta FAEP, atualmente vinculada à SEEDUC, para o quadro de pessoal da FAETEC. Em seguida, o processo foi novamente encaminhado à SECC para a adoção das medidas cabíveis. Todavia, a Assessoria Jurídica da SEEDUC (66931785) observou a ausência de manifestações dos demais órgãos diretamente envolvidos na matéria, notadamente da SECTI e da FAETEC. Diante disso, a SEEDUC solicitou a manifestação dos referidos órgãos, com vistas à adequada instrução processual. (67155131).De acordo com Ofício SEEDUC/GABSEC Nº283/2024 (72429563), a FAETEC manifestou-se de maneira inconclusiva, provocando a revisão da instrução processual, motivo pelo qual o processo foi encaminhado à Comissão de Acompanhamento e Monitoramento Econômico-Financeiro do Regime de Recuperação Fiscal - COMISARRF/SEFAZ solicitando a análise à luz da execução do Regime de Recuperação Fiscal. Posteriormente, a COMISARRF (72795939) remeteu o processo à Procuradoria Geral do Estado - PGE para preciação da matéria em observância ao disposto na Orientação Administrativa nº 04.Orientação Administrativa PGEnº 04I. Devem ser objeto de prévio exame jurídico, com Parecer conclusivo do Órgão Jurídico Local ou Setorial, as matérias que possam ter impacto sobre o Regime de Recuperação Fiscal do Estado, previsto na Lei Complementar nº 159 (tais como as vedações constantes do art. 8º da citada lei), submetendo-se sempre tal parecer ao Procurador do Estado titular da Assessoria Jurídica da Secretaria de Estado a que esteja vinculado.II. Presume-se a repercussão geral para a Administração Pública estadual, para fins de incidência do disposto no art. 4º, inciso IV, da Lei Estadual nº 5.414/2009, e consequente sujeição obrigatória à aprovação do Procurador-Geral do Estado, dos pareceres exarados sobre as matérias que possam ter impacto no Regime de Recuperação Fiscal do Estado, exceto aquelas que já tenham sido objeto de análise pela Procuradoria-Geral do Estado. Publicado: DO I, de 08/08/18 Pág. 23Ato contínuo, a PGE remeteu o processo à Assessoria Jurídica da FAETEC a fim de conceder integral cumprimento à Orientação Administrativa PGERJ nº 04 com reforço da instrução processual para o parecer conclusivo ao Procurador do Estado(72906635). A Assessoria Jurídica da FAETEC responde informando que a proposta de ato normativo proposto pela SEEDUC não estava acompanhado de documentos estabelecidos pelo Art. 4º do Decreto nº 31.869/2022, o que s.m.j. impedia a elaboração do parecer conclusivo por esta assessoria (72946282). Art. 4º Incumbe aos Secretários de Estado e aos titulares dos demais órgãos diretamente subordinados ao Governador do Estado, observadas as suas respectivas competências, oferecer a exame final do Gabinete Civil proposta para a elaboração de atos normativos ou regulamentares que considerem necessário editar, referidos nos arts. 110, I, II, III e IV, 145, IV e VI, 148, II, e 211, § 3º, da Constituição do Estado, à qual constituirá processo no órgão proponente em que serão anexados obrigatoriamente:I - a exposição de motivos, as notas explicativas e as justificativas para a edição do ato;II - o projeto do ato normativo;III - o parecer conclusivo do órgão de assessoramento jurídico da respectiva Secretaria de Estado, quanto à constitucionalidade e à juridicidade da proposição, bem como sobre a forma do ato a ser editado.No intervalo em questão, não ocorreu qualquer alteração na tramitação processual. Não obstante, no presente exercício, a SEEDUC instrui o processo com os documentos estabelecidos pelo Decreto supracitado anexando a Minuta do Projeto de Lei (130562126), a Justificativa do Projeto de Lei (130574847), bem como a Nota Técnica 2026-02 (130528267), onde concluiu que:Os servidores concursados da FAEP, cujos cargos foram instituídos pela Lei nº 2.162/1993, mantêm vínculo jurídico com a FAETEC, ainda que em exercício na SEEDUC; A Lei nº 2.512/1996 não promoveu alteração de regime jurídico, tendo sido equivocada a interpretação administrativa que os absorveu como servidores da SEEDUC; O desenvolvimento funcional desses servidores deve observar as regras aplicáveis às respectivas carreiras, conforme assegurado na legislação de criação dos cargos; A ausência de menção expressa aos cargos na reorganização promovida pela Lei nº 2.735/1997 não afasta direitos adquiridos; O direito à percepção de vencimentos conforme o Plano de Cargos e Vencimentos da FAETEC possui natureza de direito subjetivo, não se confundindo com aumento remuneratório; O Regime de Recuperação Fiscal não constitui óbice à recomposição da legalidade remuneratória; Em complemento, a SEEDUC inseriu nova estimativa de impacto orçamentário com os valores abaixo discriminados (131868597):202620272028R$ 92.819.500 R$ 185.639.001R$ 185.639.001*Valor referente à aplicação a partir de julho de 2026. A SUPGP/SEEDUC (131869119) informa que a estimativa de impacto considera todos os servidores ativos estando no plano financeiro de previdência. Além disso, para Adicionais de Qualificação, utilizou-se as informações contidas no Sistema Integrado de Recursos Humanos - SIGRH, não considerando majorações futuras.Diante do exposto, solicitamos esclarecimentos da Subsecretaria de Gestão de Pessoas - SUBGEP acerca da metodologia utilizada para a apuração do impacto orçamentário apresentado pela Secretaria de Estado de Educação, tendo em vista a existência de divergência relevante entre os valores projetados para os exercícios de 2023 e 2026, os quais indicam redução expressiva de R$ 275 milhões para R$ 185,6 milhões.Após o devido esclarecimento dessa informação, e com vistas ao prosseguimento da análise orçamentária por esta Subsecretaria Adjunta, solicitamos o encaminhamento do demonstrativo de impacto orçamentário da proposta com a adequada segregação dos efeitos financeiros relativos aos servidores ativos, inativos e pensionistas, acompanhada da discriminação dos respectivos quantitativos de cada grupo. Tal detalhamento mostra-se necessário em razão da existência de órgãos distintos responsáveis pelo pagamento das correspondentes despesas.Isto posto, sugerimos o encaminhamento do p.p. à SUBGEP para providências cabíveis. GILZA LOPES SILVEIRA DE MELLOCoordenadora de Limites de Despesas BEATRIZ MARTINS DE SÁSuperintendente de Estudos Fiscais De acordo.À Subsecretaria de Orçamento - SUBOR. MONICA MARIA DE SOUSASubsecretária Adjunta de OrçamentoRio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "Este é um despacho orçamentário importante: confirma o impacto financeiro da proposta e trata da capacidade do Estado para absorver a despesa."
    },
    {
      "number": "134970152",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "24/06/2026",
      "unit": "SEPLAG/SUPDP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNy2Z9uui8MHlJE9BgcQOG7EpJLJzI5phyU7TP16oSyMb4Uv_7DGCpMa5riMTGuWUV8FHhJEkiq9XW-iEkgQraw",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Gestão de Pessoas À SUBGEP,Por pertinência e considerando o lapso de tempo desde a última manifestação desta Superintendência de Planejamento e Desenvolvimento de Pessoas/SUBGEP (documento SEI nº 61568455), cabe atualização do impacto orçamentário e financeiro da proposta de enquadramento dos servidores da subcategoria EX FAEP na tabela remuneratória da FAETEC. Desta forma, segue abaixo quadro resumo atualizado do impacto orçamentário e financeiro (em Milhões R$): SITUAÇÃOquantidade totalIMPACTO ANUALIMPACTO MENSALATIVOS3.700160,0913,34INATIVOS3.04546,933,91TOTAL6.745207,0217,25 Como premissas utilizamos como base os dados do Sistema de Gestão de Recursos Humanos - SIGRH-RJ. Para realização do enquadramento dos servidores da subcategoria EX FAEP na tabela remuneratória da FAETEC, consideramos: a) Cada dois anos de exercício corresponde a um nível na Tabela da FAETEC.b) Para cargos de nível superior utilizamos como hipótese que todos seriam enquadrados no nível de especializaçãoc) Para cargos de nível médio utilizamos como hipótese que todos seriam enquadrados no nível de graduação Assim, recomenda-se o envio à SUBPLO/SEPLAG para conhecimento do exposto. Atenciosamente, Viviane Alves SimõesSuperintendente de Planejamento e Desenvolvimento de PessoasID 5025316-6Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "Este é um despacho orçamentário importante: confirma o impacto financeiro da proposta e trata da capacidade do Estado para absorver a despesa."
    },
    {
      "number": "134999951",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "24/06/2026",
      "unit": "SEPLAG/SUBGEP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNMPSzk3p8VvfA9JZf87OckfBkBrZV2aJjs2n2jfiz_rAwXXcnLiDgv5kcMec8vKTHcifw8C8Cp5Y-SF-I_e09MR",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Gestão de Pessoas À SUPDP,Em atenção ao conteúdo do Despacho (index. 134970152) encaminho os autos para verificação da viabilidade quanto ao pleito de atualização do impacto orçamentário e financeiro da proposta de enquadramento dos servidores da subcategoria EX FAEP na tabela remuneratória da FAETEC.Atenciosamente, Lucas Castro de OliveiraAssessor Jurídico - SUBGEP/SEPLAGID. Funcional n.º 5139055-8Rio de Janeiro, 24 de junho 2026.",
      "excerptVersion": 3,
      "simpleExplanation": "É despacho de encaminhamento: manda o processo para outro setor tomar ciência ou providências. Sozinho, não aprova nem nega."
    },
    {
      "number": "135118796",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "25/06/2026",
      "unit": "SEPLAG/SUBORC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNOUCGnzOB4F2zLmbo0LwfaDcqATAp9CVuTm6t7FIObLLHWE9gWEo1UFJHPtjp2boYX9quO05moc6Vkrvo7OnlwX",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Orçamento À Subsecretaria de Gestão de Pessoas,Encaminho o p.p. para conhecimento e providências cabíveis, tendo em vista as informações prestadas pela Subsecretaria Adjunta de Orçamento desta Subsecretaria no Despacho SEI nº 134225890.Atenciosamente, Rio de Janeiro, na data da assinatura MARIA DE FATIMA LOPES LEITEAssessora-ChefeSubsecretaria de OrçamentoID Funcional: 2025243-9",
      "excerptVersion": 3,
      "simpleExplanation": "É despacho de encaminhamento: manda o processo para outro setor tomar ciência ou providências. Sozinho, não aprova nem nega."
    },
    {
      "number": "135156870",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "26/06/2026",
      "unit": "SEPLAG/SUBGEP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPhYCur99_F9-KWc__et12YphB2g7I8P01nnZfOA9RuKItummJD-28Fek9Q8mGf7zygo9bq9Tify-Mfuo1tUA0g",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Gestão de Pessoas À SUPDP, Em prosseguimento, tendo em vista as informações prestadas pela Subsecretaria Adjunta de Orçamento desta Subsecretaria no Despacho SEI nº 134225890.Atenciosamente, Bárbara BarcelosAssessora ChefeID Funcional 5109492-4Subsecretaria de Gestão de Pessoas - SUBGEP/SEPLAGRio de Janeiro, 26 de junho de 2026.",
      "excerptVersion": 3,
      "simpleExplanation": "O documento tem linguagem de continuidade. É positivo para tramitação, mas não equivale à aprovação final."
    },
    {
      "number": "135348861",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "30/06/2026",
      "unit": "SEPLAG/SUPDP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNP5Ta3UkzSuxgbhxFbSHh35iwLuLIjTPFqjgWCaNFonDafEewMifqWOoOLNBLIhMspvTG8MMnUTVsQP7gYlTQYX",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Gestão de Pessoas À SUBGEP,Tendo em vista o solicitado através do documento SEI nº 134225890, cabe discorrer que em 2023, com base em dados extraídos do SIGRH-RJ, esta Superintendência de Planejamento e Desenvolvimento de Pessoas - SUPDP calculou o impacto referente ao enquadramento dos servidores classificados como “EX-FAEP” na tabela remuneratória da FAETEC, utilizando como premissas: a) Enquadramento conforme o Tempo de Serviço de cada servidor, considerando que a cada 2 anos corresponde a 1 nível da Tabela Remuneratória da FAETEC;b) Os servidores de nível superior foram enquadrados considerando a hipótese de que todos teriam o grau de especialização; ec) Os servidores de nível médio foram enquadrados considerando a hipótese que todos tivessem concluído a graduação. Com base nesses parâmetros a estimativa de impacto em 2023 foi a seguinte, em R$ Milhões: SITUACAOVINCULOSIMPACTO ANUAL BRUTOAPOSENTADO2.73150,68ATIVO4.316224,62TOTAL7.047275,30Nota: Considerou-se férias, 13º salário e patronal. Com base na folha de Maio de 2026, esta Superintendência atualizou a estimativa de impacto orçamentário considerando as mesmas premissas utilizadas no ano de 2023. Porém, é importante destacar que foi implementado, no ano de 2025, a rubrica “ Complemento Piso EX – FAEP”. Tal verba complementa o vencimento base da categoria, de forma que nenhum servidor receba valores inferiores ao salário mínimo (R$ 1.621), além disso, esta mesma verba compõe a base de cálculo para o triênio destes servidores. Nesse novo contexto, segue a estimativa de impacto em 2026 , em R$ Milhões:SITUACAOVINCULOSIMPACTO ANUAL BRUTOAPOSENTADO3.04546,93ATIVO3.700160,09TOTAL6.745207,02 Nota: Considerou-se férias, 13º salário e patronal. Portanto, o pagamento da verba “Complemento EX-FAEP”, implementada em 2025, que é paga para 6.700 servidores (99% do total da categoria), é o principal motivo da redução da estimativa de impacto referente ao enquadramento dos servidores EX FAEP na tabela remuneratória da FAETEC. Desta forma, restitui-se para ciência e com sugestão de posterior retorno à Subsecretaria de Orçamento/SEPLAG. Viviane Alves SimõesSuperintendente de Planejamento e Desenvolvimento de PessoasID 5025316-6 Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "Este é um despacho orçamentário importante: confirma o impacto financeiro da proposta e trata da capacidade do Estado para absorver a despesa."
    },
    {
      "number": "135422897",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "01/07/2026",
      "unit": "SEPLAG/SUBGEP",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNN1Mfu-UUj7M8MIp8BKhutFxBDt-rmbobbUgoZDkp3_OvaLVWwifkMBKErK5nrkvxEXJlOOfjiWZMzr3AiOc4kN",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Gestão de Pessoas À Subsecretaria de Orçamento/SEPLAG, Trata-se de retorno dos autos para atendimento ao solicitado através do documento SEI nº 134225890.O setor técnico desta Pasta se manifestou, através do despacho (135348861), acerca da estimativa de impacto financeiro referente ao enquadramento dos servidores EX FAEP na tabela remuneratória da FAETEC, sugerindo o retorno à essa Subsecretaria.Nesse sentido, restituo o presente para conhecimento e providências cabíveis.Atenciosamente, FELIPE DE CARVALHO PIRESSubsecretário de Gestão de Pessoas - SUBGEPSecretaria de Estado de Planejamento e GestãoId. Funcional nº 5000357-7Rio de Janeiro, 30 de junho de 2026.",
      "excerptVersion": 3,
      "simpleExplanation": "É despacho de encaminhamento: manda o processo para outro setor tomar ciência ou providências. Sozinho, não aprova nem nega."
    },
    {
      "number": "135546582",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "01/07/2026",
      "unit": "SEPLAG/SUBORC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNNjhDA-b-YbNrPSkgth_FebAsV6ie_uDpo4VdlYoFsUlADPeQA5t1FFam1x02nio1Uu4XnHEfJ-HcBs-q7ggeVO",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Orçamento À Subsecretaria Adjunta de Orçamento, Considerando o Despacho SEI nº 135422897, encaminho o p.p. para conhecimento e providências cabíveis.Rio de Janeiro, na data da assinatura MARIA DE FATIMA LOPES LEITEAssessora-ChefeSubsecretaria de OrçamentoID Funcional: 2025243-9",
      "excerptVersion": 3,
      "simpleExplanation": "É despacho de encaminhamento: manda o processo para outro setor tomar ciência ou providências. Sozinho, não aprova nem nega."
    },
    {
      "number": "135635411",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "03/07/2026",
      "unit": "SEPLAG/SUPEFIS",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNMYkLnVt-6OC0KhLUXmmK8nkMh3iZB2M4pkI7vJbdTpgQUg4uR2nNyzGa26ALU6qjw1GrfWMV_GDXSryaSb6aMV",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Orçamento À Subsecretaria Adjunta de Orçamento, Trata-se de solicitação da Secretaria de Estado de Educação - SEEDUC, visando análise da viabilidade e instrumentalização da migração/transferência de servidores concursados da extinta Fundação de Apoio à Escola Pública – FAEP, que fazem parte atualmente do quadro de pessoal da SEEDUC, para a estrutura da Fundação de Apoio à Escola Técnica – FAETEC. No ínterim do processo consta a solicitação desta Subsecretaria (134225890) para a Subsecretaria de Gestão de Pessoas - SUBGEP encaminhar o demonstrativo de impacto orçamentário da proposta com a adequada segregação dos efeitos financeiros relativos aos servidores ativos, inativos e pensionistas, acompanhada da discriminação dos respectivos quantitativos de cada grupo.Em despacho (135348861), a Superintendência de Planejamento e Desenvolvimento de Pessoas -SUPDP/SEPLAG informa o impacto referente ao enquadramento dos servidores classificados como “EX-FAEP” na tabela remuneratória da FAETEC para os anos de 2023 e 2026, utilizando como premissas: a) Enquadramento conforme o Tempo de Serviço de cada servidor, considerando que a cada 2 anos corresponde a 1 nível da Tabela Remuneratória da FAETEC;b) Os servidores de nível superior foram enquadrados considerando a hipótese de que todos teriam o grau de especialização; ec) Os servidores de nível médio foram enquadrados considerando a hipótese que todos tivessem concluído a graduação. Assim, a estimativa de impacto em 2023 , em R$ Milhões, foi: Contudo, com base na folha de Maio -2026, foi calculado novo impacto, em R$ Milhões , para 2026: Cabe, então, a esta Subsecretaria Adjunta a análise acerca do impacto no orçamento anual do RIOPREVIDÊNCIA, da FAETEC e da SEEDUC, órgãos envolvidos na questão. Diante disso, a seguir, consta Quadro Demonstrativo da Despesa de Pessoal, considerando a liquidação da folha de pesssoal até o mês de Maio/2026. No que compete aos servidores inativos e aos pensionistas, foi apurado o impacto orçamentário no âmbito do RIOPREVIDÊNCIA, considerando somente o Plano Financeiro: UO 20341 - RIOPREVIDÊNCIA Dotação Atual (A)19.541.369.492Contingenciado (B)5.387.698.001Orçamento Disponível (LDE) [C=A-B]14.153.671.491Liquidação até Maio/20267.759.370.444Projeção 2026 (D)18.397.449.468Saldo (E=C-D)- 4.243.777.977Demanda do Processo SEI-030029/004475/2023 (F)46.930.000Saldo Final (E-F)- 4.290.707.977 Conforme a Nota Técnica 2026-02 (130528267) conclui que os servidores concursados da FAEP, cujos cargos foram instituídos pela Lei nº 2.162/1993, mantêm vínculo jurídico com a FAETEC, ainda que em exercício na SEEDUC. Portanto, a análise do impacto orçamentário dos servidores ativos foi considerada o orçamento da SEEDUC e da FAETEC, conforme demonstrativo abaixo: UO 18010 - SEEDUCDotação Atual (A)4.856.594.474Contingenciado (B)425.589.070Orçamento Disponível (LDE) [C=A-B]4.431.005.404 Provável Excesso de Arrecadação (5ª NT SEFAZ) (D)383.581.956Liquidação até Maio/20262.159.117.314Projeção 2026 (E)5.247.968.182Saldo [F=C+D-E]- 433.380.822Demanda do Processo SEI-030029/004475/2023 (G)160.090.000Saldo Final [H=F - G]- 593.470.822 Para a apuração da análise do impacto orçamentário, foi adotada a metodologia na SEEDUC considerando todas as ações orçamentárias que contemplam as despesas de pessoal e encargos sociais e todas as fontes de recursos que custeam esta despesa. Essa demada representa 3% da projeção da despesa de pessoal para o exercício na SEEDUC. UO 40440 - FAETECDotação Atual (A)963.900.906Contingenciado (B)-Orçamento Disponível (LDE) [C=A-B]963.900.906Liquidação até Maio/2026343.773.180Projeção 2026 (D)832.982.101Saldo [E=C-D]130.918.805Demanda do Processo SEI-030029/004475/2023 (F)160.090.000Saldo Final [G=E-F]- 29.171.195 Diante das informações aqui prestadas, sugerimos o encaminhamento do p.p. à SEEDUC. GILZA LOPES SILVEIRA DE MELLOCoordenadora de Limites de Despesas BEATRIZ MARTINS DE SÁSuperintendente de Estudos Fiscais De acordo.À Subsecretaria de Orçamento.MONICA MARIA DE SOUSASubsecretária Adjunta de Orçamento",
      "excerptVersion": 3,
      "simpleExplanation": "Este é um despacho orçamentário importante: confirma o impacto financeiro da proposta e trata da capacidade do Estado para absorver a despesa."
    },
    {
      "number": "135780300",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "06/07/2026",
      "unit": "SEPLAG/SUBORC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPgO9nwdIVe-KIKhcvgYvbvXOhqQLpqjZvOHqav4L-bkWpC2RmllS1iT88yvKtAR9xb72GufT1gMlQjlsZOq2ch",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoSubsecretaria de Orçamento À Chefia de Gabinete da Secretaria de Estado de Planejamento e Gestão,Sugerimos o encaminhamento do p.p. à Secretaria de Estado de Educação - SEEDUC, tendo em vista as informações prestadas pela Subsecretaria Adjunta de Orçamento desta Subsecretaria no Despacho SEI nº 135635411.Atenciosamente, Rio de Janeiro, na data da assinatura PABLO VILLARIMSubsecretário de OrçamentoID. Funcional: 5000317-8",
      "excerptVersion": 3,
      "simpleExplanation": "Documento produzido por SEPLAG/SUBORC. A leitura deve ser combinada com o movimento seguinte do SEI."
    },
    {
      "number": "136041260",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "08/07/2026",
      "unit": "SEPLAG/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPsEDrAJ9aOl5Yyk4norivyObGeEXQ2EzZd_QtVq54MS9hdamm5--ujc5tAagzj_LcwrWYGiUHvD_0RLOqPEL8B",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de Planejamento e GestãoGabinete do Secretário À Chefia de Gabinete da Secretaria de Estado de Educação - SEEDUC/CHEGAB, Cumprimentando-o cordialmente, em atenção ao despacho (135780300) proveniente da Subsecretaria de Orçamento (SUBORC), encaminhamos o presente adminstrativo para apreciação das informações prestadas pela Subsecretaria Adjunta de Orçamento da referida Subsecretaria no Despacho SEI nº 135635411. Atenciosamente, DEBORA SADERChefe de GabineteID Funcional n.º 5007702-3 Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "Documento produzido por SEPLAG/CHEGAB. A leitura deve ser combinada com o movimento seguinte do SEI."
    },
    {
      "number": "136143524",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "08/07/2026",
      "unit": "SEEDUC/CHEGAB",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNN0iwaM8pLA7f5v3PxL-FB_QgFF3Hikp2leciRD2ivNVMGq_ZNBdXN6H9FM4-jnYIrq9-5wPuDbCSggQmuu09GB",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoGabinete do Secretário À SUPOFConsiderando a manifestação de id 136041260, encaminho o p.a. tendo em vista o impacto orçamentário. Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "É despacho de encaminhamento: manda o processo para outro setor tomar ciência ou providências. Sozinho, não aprova nem nega."
    },
    {
      "number": "136321484",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "10/07/2026",
      "unit": "SEEDUC/SUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNMUYo2ccRp0meD284sV0G3GkwCi-JLXZ8DsPDYn-P84-dovZTF_L8l4xrbZAg6h8pcw3BK7Dxw4hFfNAcbM6luh",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria Executiva À Assessoria de Orçamento e Finanças- (SEEDUC/ASSUPOF), Encaminhamos o presente processo para ciência e as providências que couberem, tendo em vista o contido no despacho SEEDUC/CHEGAB nº 136143524. Pamela CruzAssessoria SUPOFID 51404281 Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "É despacho de encaminhamento: manda o processo para outro setor tomar ciência ou providências. Sozinho, não aprova nem nega."
    },
    {
      "number": "136413580",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "13/07/2026",
      "unit": "SEEDUC/ASSUPOF",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPFB9Sqzp7CblQc9lauvCjEYmIXrFKS5pIGBZEuW7HMkM_vb66bTRDcYBmSwhFmnIw1BXZFfITHnhm-SM7HhIoM",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria Executiva À Assessoria da Subsecretaria Executiva - ASSUBEXE, Trata-se de solicitação da Secretaria de Estado de Educação - SEEDUC, visando análise da viabilidade e instrumentalização da migração/transferência de servidores concursados da extinta Fundação de Apoio à Escola Pública – FAEP, que fazem parte atualmente do quadro de pessoal da SEEDUC, para a estrutura da Fundação de Apoio à Escola Técnica – FAETEC. No ínterim do processo consta a solicitação desta Subsecretaria (134225890) para a Subsecretaria de Gestão de Pessoas - SUBGEP encaminhar o demonstrativo de impacto orçamentário da proposta com a adequada segregação dos efeitos financeiros relativos aos servidores ativos, inativos e pensionistas, acompanhada da discriminação dos respectivos quantitativos de cada grupo.Em atenção ao informado pela SEPLAG, por meio do doc. SEI 135635411, ressalta-se, que no momento não há disponibilidade orçamentária para atendimento da presente demanda, entretanto estaremos acompanhando o orçamento da SEEDUC quanto ao atendimento ao pleito, conforme reforçando o posicionamento ao doc. SEI 133607874. Dessa forma, encaminhamos o p.p. para essa Assessoria para providências. Gilvania Amaral Superintendente de Orçamento e FinançasID 5108551-8Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "O documento aponta problema de disponibilidade orçamentária. Isso é obstáculo financeiro, não necessariamente negativa jurídica do pedido."
    },
    {
      "number": "136500728",
      "type": "Despacho",
      "date": "13/07/2026",
      "unit": "SEEDUC/ASSUBEXE",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPLs80XliHgrpD1YoDNI_W6ddn7kr9xHk7IWk4Qv7c2QW2ERtowapFtBC5cy4sij8M3M68LNLO27zhqMkmCb53I",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoSubsecretaria ExecutivaÀ Chefia de Gabinete,Para ciência da análise técnica proferida pela SUPOF (), acerca das respostas a solicitação da SEEDUC, visando análise da viabilidade e instrumentalização da migração/transferência de servidores concursados da extinta FAEP para a estrutura da FAETEC. José Mauro BrazAssessor/SUBEXEID.: 5114243-0 Rio de Janeiro, 13 julho de 2026",
      "excerptVersion": 3,
      "simpleExplanation": "Documento produzido por SEEDUC/ASSUBEXE. A leitura deve ser combinada com o movimento seguinte do SEI."
    },
    {
      "number": "136546268",
      "type": "Despacho de Encaminhamento de Processo",
      "date": "14/07/2026",
      "unit": "SEEDUC/GABSEC",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?GL1OGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPRxzNcxMnnMjRbqRKc_kSyTyDD4iErkZvlfR7C9buANc5ByuI3wkdjNQuAu25YgCs1QbnO5fvfPUZVxVW-92Za",
      "excerpt": "Governo do Estado do Rio de JaneiroSecretaria de Estado de EducaçãoGabinete do Secretário À FAETECConsiderando o despacho de ID 136500728 sobre a viabilidade e instrumentalização da migração/transferência de servidores concursados da extinta FAEP para a estrutura da FAETEC encaminho o p.a. para analise e manifestação. Atenciosamente, Rafaela Fontes Rio de Janeiro, na data da assinatura",
      "excerptVersion": 3,
      "simpleExplanation": "É despacho de encaminhamento: manda o processo para outro setor tomar ciência ou providências. Sozinho, não aprova nem nega."
    },
    {
      "number": "137308944",
      "type": "Ofício - NA 629",
      "date": "23/07/2026",
      "unit": "FAETEC/PRESI",
      "publicUrl": "https://sei.rj.gov.br/sei/modulos/pesquisa/md_pesq_documento_consulta_externa.php?G1lOGpA1t27_rOtfzN4oyNSeqE5NT-gftYuXYZb2oNPPJaYigKgT37xBxDUmSLkckiK1Zbg_PFlQazNHrL8rM4ZSfMOPKhicrhvx72gp22VAVsX5fXu5_Z-azLuE3ck",
      "excerpt": "Of.FAETEC/PRESI Nº629\nAssunto: Avaliação da possibilidade jurídica da migração para a FAETEC e da possibilidade de uso do PROPAG na resolução da solicitação da FAEP.\n\nA Presidência da FAETEC solicita parecer da Procuradoria/ASSJUR-SEEDUC nos termos expostos. O processo trata da regularização da situação jurídico-funcional dos servidores de apoio técnico-administrativo oriundos do concurso público realizado pela antiga Fundação de Apoio à Escola Pública - FAEP, no ano de 1993.\n\nO ofício registra que a Nota Técnica nº 2026-02 (doc. SEI 130528267), da SUPGP/SEEDUC, concluiu que os servidores concursados da FAEP, cujos cargos foram instituídos pela Lei nº 2.162/1993, mantêm vínculo jurídico com a FAETEC, ainda que em exercício na SEEDUC, razão pela qual a análise do impacto orçamentário considerou tanto o orçamento da SEEDUC quanto o da FAETEC.\n\nTambém menciona a solicitação da SEEDUC sobre a viabilidade e instrumentalização da migração/transferência desses servidores para a estrutura da FAETEC; o pedido da SEPLAG/SUPEFIS para demonstrativo de impacto orçamentário segregado por ativos, inativos e pensionistas; e o posicionamento da SEPLAG (doc. SEI 135635411), que ressalta não haver, no momento, disponibilidade orçamentária para atendimento da demanda, embora o orçamento da SEEDUC esteja sendo monitorado.\n\nDiante disso, a FAETEC solicita à Procuradoria Geral do Estado/ASSJUR-SEEDUC: 1) avaliar a necessidade ou não de lei para a migração/transferência dos servidores da FAEP para a estrutura da FAETEC; 2) avaliar a possibilidade de utilização do PROPAG como instrumento jurídico-administrativo para a resolução da solicitação da FAEP, aliado à expansão de matrículas para atender às metas do PROPAG, considerando os aspectos legais e orçamentários já apontados; 3) avaliar outras questões jurídicas relevantes para a solução da questão.\n\nAssina Eduardo Chow de Martino Tostes, Presidente da FAETEC, em 23 de julho de 2026.",
      "excerptVersion": 4,
      "simpleExplanation": "Ofício positivo e estratégico: a Presidência da FAETEC pede parecer jurídico sobre a migração para a FAETEC, a necessidade de lei e a possibilidade de usar o PROPAG como caminho jurídico-administrativo para superar a trava orçamentária."
    }
  ],
  "analysis": {
    "mode": "automatic",
    "phase": {
      "title": "Aguardando parecer da Jurídica da Educação",
      "explanation": "Depois do Ofício NA 629 da FAETEC/PRESI, o processo foi recebido pela SEEDUC/ASSJUR em 24/07/2026 às 11:17. A etapa agora é a análise jurídica sobre migração, necessidade de lei e possível uso do PROPAG.",
      "nextSteps": [
        "Parecer da SEEDUC/ASSJUR",
        "Definição sobre necessidade de lei e uso do PROPAG",
        "Remessa para SEEDUC/GABSEC, SEPLAG, PGE ou Casa Civil"
      ]
    },
    "result": "Avançou mais um passo: o processo foi recebido pela SEEDUC/ASSJUR para análise jurídica do Ofício NA 629, da FAETEC.",
    "resultLevel": "positive",
    "summary": "Em 24/07/2026 às 11:17, o processo foi recebido na SEEDUC/ASSJUR. Isso confirma que o Ofício NA 629, da FAETEC/PRESI, saiu da fase de simples envio e entrou efetivamente na Assessoria Jurídica da Educação. O documento da FAETEC pediu parecer sobre a possibilidade jurídica de migração/transferência dos servidores ex-FAEP para a FAETEC, sobre a necessidade ou não de lei e sobre o possível uso do PROPAG como instrumento jurídico-administrativo para ajudar a resolver a demanda.",
    "practicalReading": "A novidade é positiva, mas ainda não é decisão final. O processo agora está no setor que pode apontar o caminho legal: se precisa de projeto de lei, se deve ir à PGE ou Casa Civil, se o PROPAG pode ser usado e como tratar a trava orçamentária. A falta de disponibilidade orçamentária continua sendo o principal risco, mas a tramitação mostra busca de solução jurídica, não arquivamento.",
    "conclusion": "O processo ganhou fôlego e agora está oficialmente na análise jurídica da SEEDUC. O próximo documento da ASSJUR será decisivo para dizer se a migração pode seguir por lei, PROPAG, PGE/Casa Civil ou se haverá novo pedido de ajuste.",
    "numbers": [
      {
        "value": "R$ 207,02 milhões",
        "label": "Custo total por ano",
        "detail": "R$ 160,09 mi para ativos e R$ 46,93 mi para aposentados"
      },
      {
        "value": "R$ 17,25 milhões",
        "label": "Custo aproximado por mês",
        "detail": "R$ 13,34 mi para ativos e R$ 3,91 mi para aposentados"
      },
      {
        "value": "6.745 pessoas",
        "label": "Total alcançado pela proposta",
        "detail": "3.700 ativos e 3.045 aposentados"
      }
    ],
    "signals": [
      "O processo foi recebido pela SEEDUC/ASSJUR em 24/07, confirmando que o Ofício NA 629 entrou na etapa jurídica e não ficou parado na FAETEC."
    ],
    "risks": [
      "A ASSJUR pode concluir que é necessário projeto de lei, manifestação da PGE/Casa Civil ou nova solução orçamentária antes de qualquer avanço concreto."
    ],
    "nextMovement": "Aguardar o parecer da SEEDUC/ASSJUR; se for favorável, o melhor caminho seria seguir para SEEDUC/GABSEC, SEPLAG, PGE ou Casa Civil."
  },
  "history": [
    {
      "period": "Origem",
      "text": "Os servidores ingressaram por concurso da antiga FAEP. Após reorganizações administrativas, permaneceram em exercício na SEEDUC, enquanto a categoria sustenta que o vínculo jurídico e a evolução funcional deveriam acompanhar a estrutura da FAETEC."
    },
    {
      "period": "2010 a 2022",
      "text": "A Lei estadual 5.766/2010 transferiu determinados servidores da SEEDUC para a FAETEC, mas não resolveu automaticamente todo o grupo ex-FAEP. Em 2022, uma proposta de extensão foi aprovada pela ALERJ, mas acabou vetada porque esse tipo de proposta precisava ter sido apresentado pelo governador."
    },
    {
      "period": "2023",
      "text": "Foi aberto o processo SEI-030029/004475/2023 para examinar a regularização funcional e remuneratória. Os estudos iniciais trabalharam com impacto anual próximo de R$ 275,30 milhões."
    },
    {
      "period": "Abril a junho de 2026",
      "text": "O processo recebeu Nota Técnica, justificativa e minuta de projeto de lei. A tese técnica reconheceu a permanência do vínculo originário com a FAETEC. O impacto anual foi atualizado para R$ 207,02 milhões, abrangendo 3.700 ativos e 3.045 aposentados."
    },
    {
      "period": "Situação atual",
      "text": "O registro público mais recente mostra o processo em SEEDUC/ASSJUR, após o Ofício NA 629 da FAETEC/PRESI. O ofício foi aberto e pede parecer sobre migração para a FAETEC, necessidade de lei e possível uso do PROPAG. A situação melhorou juridicamente, mas ainda depende de solução orçamentária e decisão política superior."
    },
    {
      "period": "Julho de 2026",
      "text": "A FAETEC/PRESI emitiu o Ofício NA 629 e o processo foi recebido pela SEEDUC/ASSJUR em 24/07/2026 para análise jurídica da migração, da necessidade de lei e do possível uso do PROPAG."
    }
  ]
}